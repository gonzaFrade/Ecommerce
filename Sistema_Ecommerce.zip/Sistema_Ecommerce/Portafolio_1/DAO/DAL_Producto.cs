﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DAL_Producto
    {
        SqlConnection connection = new SqlConnection("Data Source=.; Initial Catalog = pruebademo; Integrated Security = True;");
        SqlDataAdapter DataAdapter;
        SqlCommandBuilder CommandBuilder;
        DataSet ds;

        public DAL_Producto()
        {
            ds = new DataSet();
            DataAdapter = new SqlDataAdapter("Select * from Producto", connection);
            CommandBuilder = new SqlCommandBuilder(DataAdapter);
            DataAdapter.InsertCommand = CommandBuilder.GetInsertCommand();
            DataAdapter.DeleteCommand = CommandBuilder.GetDeleteCommand();
            DataAdapter.UpdateCommand = CommandBuilder.GetUpdateCommand();

            LeerDatos();
        }

        public void LeerDatos()
        {
            ds.Clear();
            DataAdapter.Fill(ds, "Producto");
        }

        public void GuardarDatos()
        {
            DataAdapter.Update(ds, "Producto");
        }

        public DataSet RetornarDataSet()
        {
            return ds;
        }
    }
}
