﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{  
    public class DAL_Venta
    {
        SqlConnection SqlConnection = new SqlConnection("Data Source=.; Initial Catalog = pruebademo; Integrated Security = True;");
        SqlCommandBuilder SqlCommandBuilder;
        SqlDataAdapter SqlDataAdapter;
        DataSet ds;

        public DAL_Venta()
        {
            ds = new DataSet();
            SqlDataAdapter = new SqlDataAdapter("Select * from Venta", SqlConnection);
            SqlCommandBuilder = new SqlCommandBuilder(SqlDataAdapter);
            SqlDataAdapter.InsertCommand = SqlCommandBuilder.GetInsertCommand();
            SqlDataAdapter.DeleteCommand = SqlCommandBuilder.GetDeleteCommand();
            SqlDataAdapter.UpdateCommand = SqlCommandBuilder.GetUpdateCommand();

            LeerDatos();
        }

        public void LeerDatos()
        {
            ds.Clear();
            SqlDataAdapter.Fill(ds, "Venta");
        }

        public void GuardarDatos()
        {
            SqlDataAdapter.Update(ds, "Venta");
        }

        public DataSet RetornarDataSet()
        {
            return ds;
        }
    }
}
