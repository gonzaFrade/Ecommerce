﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DAL_Item
    {
        SqlConnection SqlConnection = new SqlConnection("Data Source=.; Initial Catalog = pruebademo; Integrated Security = True;");
        SqlCommandBuilder SqlCommandBuilder;
        SqlDataAdapter SqlDataAdapter;
        DataSet ds;

        public DAL_Item()
        {
            ds = new DataSet();
            SqlDataAdapter = new SqlDataAdapter("Select * from Item", SqlConnection);
            SqlCommandBuilder = new SqlCommandBuilder(SqlDataAdapter);
            SqlDataAdapter.InsertCommand = SqlCommandBuilder.GetInsertCommand();
            SqlDataAdapter.DeleteCommand = SqlCommandBuilder.GetDeleteCommand();
            SqlDataAdapter.UpdateCommand = SqlCommandBuilder.GetUpdateCommand();

            LeerDatos();
        }

        public void LeerDatos()
        {
            ds.Clear();
            SqlDataAdapter.Fill(ds, "Item");
        }

        public void GuardarDatos()
        {
            SqlDataAdapter.Update(ds, "Item");
        }

        public DataSet RetornarDataSet()
        {
            return ds;
        }
    }
}
