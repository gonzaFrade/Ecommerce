﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class DAL_Cliente
    {
        SqlConnection sqlConnection = new SqlConnection("Data Source=.; Initial Catalog = pruebademo; Integrated Security = True;");
        SqlDataAdapter SqlDataAdapter;
        SqlCommandBuilder SqlCommandBuilder;
        DataSet ds;

        public DAL_Cliente()
        {
            ds = new DataSet();
            SqlDataAdapter = new SqlDataAdapter("Select * from Cliente",sqlConnection);
            SqlCommandBuilder = new SqlCommandBuilder(SqlDataAdapter);
            SqlDataAdapter.InsertCommand = SqlCommandBuilder.GetInsertCommand();
            SqlDataAdapter.UpdateCommand = SqlCommandBuilder.GetUpdateCommand();
            SqlDataAdapter.DeleteCommand = SqlCommandBuilder.GetDeleteCommand();

            LeerDatos();
        }

        public void LeerDatos()
        {
            ds.Clear();
            SqlDataAdapter.Fill(ds, "Cliente");
        }

        public void GuardarDatos()
        {
            SqlDataAdapter.Update(ds, "Cliente");
        }

        public DataSet RetornarDataSet()
        {
            return ds;
        }
    }
}
