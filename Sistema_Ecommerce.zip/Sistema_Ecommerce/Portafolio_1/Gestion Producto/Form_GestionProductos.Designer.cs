﻿namespace Portafolio_1.Gestion_Producto
{
    partial class Form_GestionProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_LimpiarTxt = new System.Windows.Forms.Button();
            this.Btn_BuscarFiltro = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lb_GestionClientes = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_BorrarDetalles = new System.Windows.Forms.Button();
            this.btn_Registrar = new System.Windows.Forms.Button();
            this.Btn_EditarProducto = new System.Windows.Forms.Button();
            this.Btn_EliminarProducto = new System.Windows.Forms.Button();
            this.txt_Categoria = new System.Windows.Forms.TextBox();
            this.txt_Precio = new System.Windows.Forms.TextBox();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Categoria = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_LimpiarTxt
            // 
            this.Btn_LimpiarTxt.BackColor = System.Drawing.Color.White;
            this.Btn_LimpiarTxt.ForeColor = System.Drawing.Color.White;
            this.Btn_LimpiarTxt.Image = global::Portafolio_1.Properties.Resources.borrador;
            this.Btn_LimpiarTxt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_LimpiarTxt.Location = new System.Drawing.Point(934, 52);
            this.Btn_LimpiarTxt.Name = "Btn_LimpiarTxt";
            this.Btn_LimpiarTxt.Size = new System.Drawing.Size(44, 28);
            this.Btn_LimpiarTxt.TabIndex = 34;
            this.Btn_LimpiarTxt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_LimpiarTxt.UseVisualStyleBackColor = false;
            this.Btn_LimpiarTxt.Click += new System.EventHandler(this.Btn_LimpiarTxt_Click);
            // 
            // Btn_BuscarFiltro
            // 
            this.Btn_BuscarFiltro.BackColor = System.Drawing.Color.White;
            this.Btn_BuscarFiltro.ForeColor = System.Drawing.Color.White;
            this.Btn_BuscarFiltro.Image = global::Portafolio_1.Properties.Resources.lupa;
            this.Btn_BuscarFiltro.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BuscarFiltro.Location = new System.Drawing.Point(882, 51);
            this.Btn_BuscarFiltro.Name = "Btn_BuscarFiltro";
            this.Btn_BuscarFiltro.Size = new System.Drawing.Size(46, 28);
            this.Btn_BuscarFiltro.TabIndex = 33;
            this.Btn_BuscarFiltro.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BuscarFiltro.UseVisualStyleBackColor = false;
            this.Btn_BuscarFiltro.Click += new System.EventHandler(this.Btn_BuscarFiltro_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(575, 56);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(118, 21);
            this.comboBox1.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(508, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Buscar por:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(699, 56);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(177, 20);
            this.textBox5.TabIndex = 30;
            // 
            // lb_GestionClientes
            // 
            this.lb_GestionClientes.AutoSize = true;
            this.lb_GestionClientes.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_GestionClientes.Location = new System.Drawing.Point(295, 49);
            this.lb_GestionClientes.Name = "lb_GestionClientes";
            this.lb_GestionClientes.Size = new System.Drawing.Size(210, 26);
            this.lb_GestionClientes.TabIndex = 29;
            this.lb_GestionClientes.Text = "Gestion Productos";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_BorrarDetalles);
            this.groupBox1.Controls.Add(this.btn_Registrar);
            this.groupBox1.Controls.Add(this.Btn_EditarProducto);
            this.groupBox1.Controls.Add(this.Btn_EliminarProducto);
            this.groupBox1.Controls.Add(this.txt_Categoria);
            this.groupBox1.Controls.Add(this.txt_Precio);
            this.groupBox1.Controls.Add(this.txt_Nombre);
            this.groupBox1.Controls.Add(this.txt_ID);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(11, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 514);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            // 
            // Btn_BorrarDetalles
            // 
            this.Btn_BorrarDetalles.BackColor = System.Drawing.Color.White;
            this.Btn_BorrarDetalles.ForeColor = System.Drawing.Color.White;
            this.Btn_BorrarDetalles.Image = global::Portafolio_1.Properties.Resources.borrador;
            this.Btn_BorrarDetalles.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BorrarDetalles.Location = new System.Drawing.Point(241, 14);
            this.Btn_BorrarDetalles.Name = "Btn_BorrarDetalles";
            this.Btn_BorrarDetalles.Size = new System.Drawing.Size(31, 28);
            this.Btn_BorrarDetalles.TabIndex = 19;
            this.Btn_BorrarDetalles.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BorrarDetalles.UseVisualStyleBackColor = false;
            this.Btn_BorrarDetalles.Click += new System.EventHandler(this.Btn_BorrarDetalles_Click);
            // 
            // btn_Registrar
            // 
            this.btn_Registrar.BackColor = System.Drawing.Color.ForestGreen;
            this.btn_Registrar.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Registrar.ForeColor = System.Drawing.Color.White;
            this.btn_Registrar.Image = global::Portafolio_1.Properties.Resources.icons8_guardar_241;
            this.btn_Registrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Registrar.Location = new System.Drawing.Point(11, 356);
            this.btn_Registrar.Name = "btn_Registrar";
            this.btn_Registrar.Padding = new System.Windows.Forms.Padding(50, 0, 28, 0);
            this.btn_Registrar.Size = new System.Drawing.Size(256, 47);
            this.btn_Registrar.TabIndex = 14;
            this.btn_Registrar.Text = "Registrar";
            this.btn_Registrar.UseVisualStyleBackColor = false;
            this.btn_Registrar.Click += new System.EventHandler(this.btn_Registrar_Click_1);
            // 
            // Btn_EditarProducto
            // 
            this.Btn_EditarProducto.BackColor = System.Drawing.Color.DodgerBlue;
            this.Btn_EditarProducto.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_EditarProducto.ForeColor = System.Drawing.Color.White;
            this.Btn_EditarProducto.Image = global::Portafolio_1.Properties.Resources.icons8_editar_16;
            this.Btn_EditarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_EditarProducto.Location = new System.Drawing.Point(11, 409);
            this.Btn_EditarProducto.Name = "Btn_EditarProducto";
            this.Btn_EditarProducto.Padding = new System.Windows.Forms.Padding(55, 0, 40, 0);
            this.Btn_EditarProducto.Size = new System.Drawing.Size(256, 47);
            this.Btn_EditarProducto.TabIndex = 13;
            this.Btn_EditarProducto.Text = "Editar";
            this.Btn_EditarProducto.UseVisualStyleBackColor = false;
            this.Btn_EditarProducto.Click += new System.EventHandler(this.Btn_EditarProducto_Click);
            // 
            // Btn_EliminarProducto
            // 
            this.Btn_EliminarProducto.BackColor = System.Drawing.Color.Red;
            this.Btn_EliminarProducto.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_EliminarProducto.ForeColor = System.Drawing.Color.White;
            this.Btn_EliminarProducto.Image = global::Portafolio_1.Properties.Resources.icons8_eliminar_16;
            this.Btn_EliminarProducto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_EliminarProducto.Location = new System.Drawing.Point(11, 462);
            this.Btn_EliminarProducto.Name = "Btn_EliminarProducto";
            this.Btn_EliminarProducto.Padding = new System.Windows.Forms.Padding(55, 0, 40, 0);
            this.Btn_EliminarProducto.Size = new System.Drawing.Size(256, 47);
            this.Btn_EliminarProducto.TabIndex = 14;
            this.Btn_EliminarProducto.Text = "Eliminar";
            this.Btn_EliminarProducto.UseVisualStyleBackColor = false;
            this.Btn_EliminarProducto.Click += new System.EventHandler(this.Btn_EliminarProducto_Click);
            // 
            // txt_Categoria
            // 
            this.txt_Categoria.Location = new System.Drawing.Point(11, 310);
            this.txt_Categoria.Name = "txt_Categoria";
            this.txt_Categoria.Size = new System.Drawing.Size(256, 20);
            this.txt_Categoria.TabIndex = 12;
            // 
            // txt_Precio
            // 
            this.txt_Precio.Location = new System.Drawing.Point(11, 236);
            this.txt_Precio.Name = "txt_Precio";
            this.txt_Precio.Size = new System.Drawing.Size(256, 20);
            this.txt_Precio.TabIndex = 11;
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Location = new System.Drawing.Point(11, 166);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(260, 20);
            this.txt_Nombre.TabIndex = 10;
            // 
            // txt_ID
            // 
            this.txt_ID.Enabled = false;
            this.txt_ID.Location = new System.Drawing.Point(13, 86);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(259, 20);
            this.txt_ID.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Categoria:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Precio:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Detalle del Producto";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Nombre,
            this.Precio,
            this.Categoria});
            this.dataGridView1.Location = new System.Drawing.Point(295, 92);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(704, 456);
            this.dataGridView1.TabIndex = 27;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            // 
            // Precio
            // 
            this.Precio.HeaderText = "Precio";
            this.Precio.Name = "Precio";
            this.Precio.ReadOnly = true;
            // 
            // Categoria
            // 
            this.Categoria.HeaderText = "Categoria";
            this.Categoria.Name = "Categoria";
            this.Categoria.ReadOnly = true;
            // 
            // Form_GestionProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 572);
            this.Controls.Add(this.Btn_LimpiarTxt);
            this.Controls.Add(this.Btn_BuscarFiltro);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lb_GestionClientes);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form_GestionProductos";
            this.Text = "Form_GestionProductos";
            this.Load += new System.EventHandler(this.Form_GestionProductos_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_LimpiarTxt;
        private System.Windows.Forms.Button Btn_BuscarFiltro;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lb_GestionClientes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_BorrarDetalles;
        private System.Windows.Forms.Button btn_Registrar;
        private System.Windows.Forms.Button Btn_EditarProducto;
        private System.Windows.Forms.Button Btn_EliminarProducto;
        private System.Windows.Forms.TextBox txt_Categoria;
        private System.Windows.Forms.TextBox txt_Precio;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_ID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        internal System.Windows.Forms.DataGridViewTextBoxColumn ID;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Precio;
        internal System.Windows.Forms.DataGridViewTextBoxColumn Categoria;
    }
}