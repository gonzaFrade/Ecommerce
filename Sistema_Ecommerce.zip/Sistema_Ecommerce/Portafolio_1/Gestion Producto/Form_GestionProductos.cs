﻿using BE;
using BLL;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Portafolio_1.Gestion_Producto
{
    public partial class Form_GestionProductos : Form
    {
        private BLL_Producto _bl_Producto = new BLL_Producto();
        public Form_GestionProductos()
        {
            InitializeComponent();
        }

        private void Form_GestionProductos_Load(object sender, EventArgs e)
        {
            Mostrar();
            // Me.dataGridView1.CurrentRow.Selected = False
            Filtrar();
        }

        private void Filtrar()
        {
            foreach (DataGridViewColumn dgv in dataGridView1.Columns)
                comboBox1.Items.Add(dgv.HeaderText);
        }

        private void InformacionProducto()
        {
            txt_ID.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txt_Nombre.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txt_Precio.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txt_Categoria.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void BorrarInformacionProducto()
        {
            txt_ID.Text = "";
            txt_Nombre.Text = "";
            txt_Precio.Text = "";
            txt_Categoria.Text = "";
        }

        private void Mostrar()
        {
            dataGridView1.Rows.Clear();

            foreach (Producto pProducto in _bl_Producto.ObtenerListaProductos())
                dataGridView1.Rows.Add(pProducto.ID.ToString(), pProducto.Nombre.ToString(), pProducto.Precio.ToString(), pProducto.Categoria.ToString());
            groupBox1.BackColor = Color.White;
        }

        private void MostrarFiltrado(List<Producto> pListaProducto)
        {
            dataGridView1.Rows.Clear();

            foreach (Producto pProducto in pListaProducto)
                dataGridView1.Rows.Add(pProducto.ID.ToString(), pProducto.Nombre.ToString(), pProducto.Precio.ToString(), pProducto.Categoria.ToString());
            groupBox1.BackColor = Color.White;
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            InformacionProducto();
        }


        private void btn_Registrar_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (_bl_Producto.ObtenerListaProductos().Count == 0)
                {
                    string _id = "1";
                    if (_bl_Producto.ObtenerListaProductos().Exists(x => x.ID == int.Parse(_id)))
                        throw new Exception("El ID que quiere ingresar ya esta en uso");
                    string _Nombre = txt_Nombre.Text;

                    if (string.IsNullOrEmpty(_Nombre))
                        throw new Exception("Ingrese un nombre!");

                    if (Information.IsNumeric(_Nombre))
                        throw new Exception("Ingrese un nombre valido! No aceptamos numeros");

                    string _precio = txt_Precio.Text;

                    if (string.IsNullOrEmpty(_precio))
                        throw new Exception("Ingrese un precio!");

                    if (!Information.IsNumeric(_precio))
                        throw new Exception("Ingrese un precio valido! Que sea numerico!");

                    string _Categoria = txt_Categoria.Text;

                    if (string.IsNullOrEmpty(_Categoria))
                        throw new Exception("Ingrese una categoria!");

                    DialogResult r = MessageBox.Show("¿Desea crear el producto?", "Crear Producto", MessageBoxButtons.YesNo);

                    if (r == DialogResult.Yes)
                    {
                        _bl_Producto.AgregarProducto(new Producto(int.Parse(_id), _Nombre, decimal.Parse(_precio), _Categoria));
                        Mostrar();
                    }
                    else
                        MessageBox.Show("Se cancelo el registro del producto");
                }
                else
                {
                    int _id = _bl_Producto.ObtenerListaProductos().Last().ID + 1;
                    if (_bl_Producto.ObtenerListaProductos().Exists(x => x.ID == _id))
                        throw new Exception("El ID que quiere ingresar ya esta en uso");
                    string _Nombre = txt_Nombre.Text;

                    if (string.IsNullOrEmpty(_Nombre))
                        throw new Exception("Ingrese un nombre!");

                    if (Information.IsNumeric(_Nombre))
                        throw new Exception("Ingrese un nombre valido! No aceptamos numeros");

                    string _precio = txt_Precio.Text;

                    if (string.IsNullOrEmpty(_precio))
                        throw new Exception("Ingrese un precio!");

                    if (!Information.IsNumeric(_precio))
                        throw new Exception("Ingrese un precio valido! Que sea numerico!");

                    string _Categoria = txt_Categoria.Text;

                    if (string.IsNullOrEmpty(_Categoria))
                        throw new Exception("Ingrese una categoria!");

                    DialogResult r = MessageBox.Show("¿Desea crear el producto?", "Crear Producto", MessageBoxButtons.YesNo);

                    if (r == DialogResult.Yes)
                    {
                        _bl_Producto.AgregarProducto(new Producto(_id, _Nombre, decimal.Parse(_precio), _Categoria));
                        Mostrar();
                    }
                    else
                        MessageBox.Show("Se cancelo el registro el cliente");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_BorrarDetalles_Click(object sender, EventArgs e)
        {
            BorrarInformacionProducto();
        }

        private void Btn_EliminarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0)
                    throw new Exception("Registra un producto para eliminar!");
                string _id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                Producto pProducto = _bl_Producto.ObtenerProducto(int.Parse(_id));
                DialogResult r = MessageBox.Show("¿Desea eliminar el producto?", "Eliminar Producto", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    _bl_Producto.EliminarProducto(pProducto);
                    Mostrar();
                    BorrarInformacionProducto();
                }
                else
                    MessageBox.Show("Se cancelo la eliminacion del producto");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_EditarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0)
                    throw new Exception("Ingrese un producto para editarlo!");
                int _id = int.Parse(txt_ID.Text);
                string _nombre = txt_Nombre.Text;
                int _precio = int.Parse(txt_Precio.Text);
                string _categoria = txt_Categoria.Text;
                Producto pProducto = new Producto(_id, _nombre, _precio, _categoria);
                DialogResult r = MessageBox.Show("¿Desea editar el producto?", "Editar producto", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    _bl_Producto.ModificarProducto(pProducto);
                    Mostrar();
                }
                else
                    MessageBox.Show("Se cancelo la editacion del producto");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_BuscarFiltro_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text.Contains("ID"))
                    MostrarFiltrado(_bl_Producto.FiltrarID(textBox5.Text));
                else if (comboBox1.Text.Contains("Nombre"))
                    MostrarFiltrado(_bl_Producto.FiltrarNombre(textBox5.Text));
                else if (comboBox1.Text.Contains("Precio"))
                    MostrarFiltrado(_bl_Producto.FiltrarPrecio(textBox5.Text));
                else if (comboBox1.Text.Contains("Categoria"))
                    MostrarFiltrado(_bl_Producto.FiltrarCategoria(textBox5.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_LimpiarTxt_Click(object sender, EventArgs e)
        {
            try
            {
                textBox5.Text = "";
                Mostrar();
                comboBox1.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }


}
