﻿using BE;
using Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_Venta
    {
        Mapper_Venta _mapper = new Mapper_Venta();

        public void AgregarVenta(Venta pVenta)
        {
            _mapper.AgregarVenta(pVenta);
        }

        public void EliminarVenta(Venta pVenta)
        {
            _mapper.EliminarVenta(pVenta);
        }

        public List<Venta> ObtenerListaVentas()
        {
            return _mapper.ObtenerListaVenta();
        }

        public Venta ObtenerVenta(Cliente pCliente)
        {
            return _mapper.ObtenerVenta(pCliente);
        }

        public List<Venta> ObtenerTodasListaVentas()
        {
            return _mapper.ObtenerTodasListaVenta();
        }
    }
}
