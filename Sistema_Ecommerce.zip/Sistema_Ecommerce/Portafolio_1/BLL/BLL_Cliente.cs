﻿using BE;
using Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_Cliente
    {
        Mapper_clientes _mapper = new Mapper_clientes();

        public void AgregarCliente(Cliente pCliente)
        {
            _mapper.AgregarCliente(pCliente);
        }

        public void EliminarCliente(Cliente pCliente)
        {
            _mapper.EliminarCliente(pCliente);
        }

        public void ModificarCliente(Cliente pCliente)
        {
            _mapper.ModificarCliente(pCliente);
        }

        public Cliente ObtenerCliente(int _dni)
        {
            return _mapper.ObtenerCliente(_dni);
        }

        public List<Cliente> ObtenerClientes()
        {
            return _mapper.ObtenerClientes();
        }

        public List<Cliente> FiltrarDNI(string _dni)
        {
            var x = from cliente in ObtenerClientes()
                    where cliente.DNI.ToString().StartsWith(_dni.ToString())
                    select cliente;
            return x.ToList();
        }

        public List<Cliente> FiltrarNombre(string _nombre)
        {
            var x = from cliente in ObtenerClientes()
                    where cliente.Nombre.ToString().StartsWith(_nombre.ToString())
                    select cliente;
            return x.ToList();
        }

        public List<Cliente> FiltrarTelefono(string _telefono)
        {
            var x = from cliente in ObtenerClientes()
                    where cliente.Telefono.ToString().StartsWith(_telefono.ToString())
                    select cliente;
            return x.ToList();
        }

        public List<Cliente> FiltrarCorreo(string _correo)
        {
            var x = from cliente in ObtenerClientes()
                    where cliente.Correo.ToString().StartsWith(_correo.ToString())
                    select cliente;
            return x.ToList();
        }
    }
}
