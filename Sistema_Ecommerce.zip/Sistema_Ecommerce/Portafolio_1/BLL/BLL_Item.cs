﻿using BE;
using Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_Item
    {
        Mapper_Item _mapper = new Mapper_Item();

        public void AgregarItem(Item pItem)
        {
            _mapper.AgregarItem(pItem);
        }

        public void EditarItem(Item pItem)
        {
            _mapper.EditarItem(pItem);
        }

        public List<Item> ObtenerListaItem(Venta pVenta)
        {
            return _mapper.ObtenerListaItem(pVenta);
        }

        public int ObtenerUltimoItem()
        {
            return _mapper.ObtenerUltimoIDItem();
        }

    }
}
