﻿using BE;
using Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLL_Producto
    {
        Mapper_Producto _mapper = new Mapper_Producto();

        public void AgregarProducto(Producto pProducto)
        {
            _mapper.AgregarProducto(pProducto);
        }

        public void EliminarProducto(Producto pProducto)
        {
            _mapper.EliminarProducto(pProducto);
        }

        public void ModificarProducto(Producto pProducto)
        {
            _mapper.ModificarProducto(pProducto);
        }

        public Producto ObtenerProducto(int ID)
        {
            return _mapper.ObtenerProducto(ID);
        }

        public List<Producto> ObtenerListaProductos()
        {
            return _mapper.ObtenerListaProductos();
        }

        public List<Producto> FiltrarID(string _id)
        {
            var x = from producto in ObtenerListaProductos()
                    where producto.ID.ToString().StartsWith(_id.ToString())
                    select producto;
            return x.ToList();
        }

        public List<Producto> FiltrarNombre(string _nombre)
        {
            var x = from producto in ObtenerListaProductos()
                    where producto.Nombre.ToString().StartsWith(_nombre.ToString())
                    select producto;
            return x.ToList();
        }

        public List<Producto> FiltrarPrecio(string _precio)
        {
            var x = from producto in ObtenerListaProductos()
                    where producto.Precio.ToString().StartsWith(_precio.ToString())
                    select producto;
            return x.ToList();
        }

        public List<Producto> FiltrarCategoria(string _categoria)
        {
            var x = from producto in ObtenerListaProductos()
                    where producto.Categoria.ToString().StartsWith(_categoria.ToString())
                    select producto;
            return x.ToList();
        }


    }
}
