﻿
namespace Portafolio_1
{
    partial class Form_ReporteProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_GestionClientes = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Fecha_inicio = new System.Windows.Forms.DateTimePicker();
            this.Fecha_Fin = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Btn_DescargarPDF = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_LimpiarTxt = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_GestionClientes
            // 
            this.lb_GestionClientes.AutoSize = true;
            this.lb_GestionClientes.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_GestionClientes.Location = new System.Drawing.Point(12, 9);
            this.lb_GestionClientes.Name = "lb_GestionClientes";
            this.lb_GestionClientes.Size = new System.Drawing.Size(299, 26);
            this.lb_GestionClientes.TabIndex = 6;
            this.lb_GestionClientes.Text = "Reporte Producto Mensual";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(140, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Fecha Inicio:";
            // 
            // Fecha_inicio
            // 
            this.Fecha_inicio.Location = new System.Drawing.Point(245, 15);
            this.Fecha_inicio.Name = "Fecha_inicio";
            this.Fecha_inicio.Size = new System.Drawing.Size(200, 20);
            this.Fecha_inicio.TabIndex = 8;
            // 
            // Fecha_Fin
            // 
            this.Fecha_Fin.Location = new System.Drawing.Point(593, 15);
            this.Fecha_Fin.Name = "Fecha_Fin";
            this.Fecha_Fin.Size = new System.Drawing.Size(200, 20);
            this.Fecha_Fin.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(506, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Fecha Fin:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nombre,
            this.Cantidad});
            this.dataGridView1.Location = new System.Drawing.Point(13, 134);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(979, 426);
            this.dataGridView1.TabIndex = 11;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.ReadOnly = true;
            // 
            // Btn_DescargarPDF
            // 
            this.Btn_DescargarPDF.Image = global::Portafolio_1.Properties.Resources.descargable;
            this.Btn_DescargarPDF.Location = new System.Drawing.Point(17, 96);
            this.Btn_DescargarPDF.Name = "Btn_DescargarPDF";
            this.Btn_DescargarPDF.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.Btn_DescargarPDF.Size = new System.Drawing.Size(178, 32);
            this.Btn_DescargarPDF.TabIndex = 12;
            this.Btn_DescargarPDF.Text = "Descargar Reporte";
            this.Btn_DescargarPDF.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_DescargarPDF.UseVisualStyleBackColor = true;
            this.Btn_DescargarPDF.Click += new System.EventHandler(this.Btn_DescargarPDF_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_LimpiarTxt);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Fecha_inicio);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Fecha_Fin);
            this.groupBox1.Location = new System.Drawing.Point(13, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(979, 51);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // Btn_LimpiarTxt
            // 
            this.Btn_LimpiarTxt.BackColor = System.Drawing.Color.White;
            this.Btn_LimpiarTxt.ForeColor = System.Drawing.Color.White;
            this.Btn_LimpiarTxt.Image = global::Portafolio_1.Properties.Resources.borrador;
            this.Btn_LimpiarTxt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_LimpiarTxt.Location = new System.Drawing.Point(863, 13);
            this.Btn_LimpiarTxt.Name = "Btn_LimpiarTxt";
            this.Btn_LimpiarTxt.Size = new System.Drawing.Size(42, 28);
            this.Btn_LimpiarTxt.TabIndex = 12;
            this.Btn_LimpiarTxt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_LimpiarTxt.UseVisualStyleBackColor = false;
            this.Btn_LimpiarTxt.Click += new System.EventHandler(this.Btn_LimpiarTxt_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = global::Portafolio_1.Properties.Resources.lupa;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.Location = new System.Drawing.Point(817, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 28);
            this.button3.TabIndex = 11;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form_ReporteProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 572);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Btn_DescargarPDF);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lb_GestionClientes);
            this.Name = "Form_ReporteProducto";
            this.Text = "Form_ReporteProducto";
            this.Load += new System.EventHandler(this.Form_ReporteProducto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_GestionClientes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker Fecha_inicio;
        private System.Windows.Forms.DateTimePicker Fecha_Fin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Btn_DescargarPDF;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Btn_LimpiarTxt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
    }
}