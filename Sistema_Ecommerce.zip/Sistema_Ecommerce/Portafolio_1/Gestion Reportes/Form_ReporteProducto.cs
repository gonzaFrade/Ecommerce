﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BE;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;

namespace Portafolio_1
{
    public partial class Form_ReporteProducto : Form
    {
        BLL.BLL_Venta _bl = new BLL.BLL_Venta();
        BLL.BLL_Item _bl_item = new BLL.BLL_Item();
        BLL.BLL_Producto _bl_producto = new BLL.BLL_Producto();
        Dictionary<string, int> cantidadesPorProducto = new Dictionary<string, int>();
        public Form_ReporteProducto()
        {
            InitializeComponent();
        }

        private void Form_ReporteProducto_Load(object sender, EventArgs e)
        {
            
        }

        private void Mostrar()
        {
            DateTime fechaInicio = Fecha_inicio.Value.Date;
            DateTime fechaFin = Fecha_Fin.Value.Date.AddDays(1).AddSeconds(-1);
            dataGridView1.Rows.Clear();
            Dictionary<string, int> cantidadesPorProducto = new Dictionary<string, int>();
            bool ventaEncontrada = false;

            foreach (Venta pVenta in _bl.ObtenerTodasListaVentas())
            {
                DateTime fechaVenta = pVenta.Fecha.Date;

                if (fechaVenta >= fechaInicio && fechaVenta <= fechaFin)
                {
                    ventaEncontrada = true;

                    foreach (Item _item in pVenta.DevolverListaItems())
                    {
                        string nombreProducto = _item.Producto().Nombre;

                        if (cantidadesPorProducto.ContainsKey(nombreProducto))
                            cantidadesPorProducto[nombreProducto] += _item.Cantidad;
                        else
                            cantidadesPorProducto[nombreProducto] = _item.Cantidad;
                    }
                }
            }

            if (!ventaEncontrada)
            {
                MessageBox.Show("¡No se encontraron ventas en el rango de fechas especificado!", "Importante");
            }

            foreach (var kvp in cantidadesPorProducto)
            {
                dataGridView1.Rows.Add(kvp.Key, kvp.Value.ToString());
            }
        }





        private void Btn_DescargarPDF_Click(object sender, EventArgs e)
        {
            try
            {
                bool respuesta = MessageBox.Show("¿Desea guardar el documento?", "", MessageBoxButtons.YesNo) == DialogResult.Yes ? true : false;
                if (respuesta == true)
                {
                    SaveFileDialog guardar = new SaveFileDialog();
                    guardar.FileName = $"Seguimiento de venta del dia.{DateTime.Now.ToString("dd.MM.yyyy.HH.mm.ss")}.pdf";
                    guardar.ShowDialog();

                    string paginahtml_texto = Properties.Resources.Plantilla_Venta_productos.ToString();
                    paginahtml_texto = paginahtml_texto.Replace("@FECHA", DateTime.Now.ToString("dd/MM/yyyy"));

                    string filas = string.Empty;
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.IsNewRow == false)
                        {
                            filas += "<tr>";
                            filas += "<td>" + row.Cells["Nombre"].Value.ToString() + "</td>";
                            filas += "<td>" + row.Cells["Cantidad"].Value.ToString() + "</td>";
                            filas += "</tr>";
                        }
                    }
                    paginahtml_texto = paginahtml_texto.Replace("@FILAS", filas);

                    if (guardar.ShowDialog() == DialogResult.OK)
                    {
                        using (FileStream stream = new FileStream(guardar.FileName, FileMode.Create))
                        {
                            Document pdfDoc = new Document(PageSize.A4, 25, 25, 25, 25);
                            PdfWriter escribir = PdfWriter.GetInstance(pdfDoc, stream);
                            pdfDoc.Open();
                            pdfDoc.Add(new Phrase(""));
                            iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(Properties.Resources._0801229dd50e7d4c15642b4490082957, System.Drawing.Imaging.ImageFormat.Png);
                            img.ScaleToFit(98, 80);
                            img.Alignment = iTextSharp.text.Image.UNDERLYING;
                            img.SetAbsolutePosition(pdfDoc.LeftMargin, pdfDoc.Top - 60);
                            pdfDoc.Add(img);
                            using (StringReader sr = new StringReader(paginahtml_texto))
                            {
                                XMLWorkerHelper.GetInstance().ParseXHtml(escribir, pdfDoc, sr);
                            }
                            pdfDoc.Close();
                            stream.Close();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Se cancelo guardar el documento");
                }
                this.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);}
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Mostrar();
        }

        private void Btn_LimpiarTxt_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message);}
        }
    }
}
