﻿using BE;
using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Portafolio_1
{
    public partial class Form_GestionVentas : Form
    {
        private BLL_Venta _bl_Venta = new BLL_Venta();
        private BLL_Item _bl_Item = new BLL_Item();
        private BLL_Producto _bl_Producto = new BLL_Producto();
        private BLL_Cliente _bl_Cliente = new BLL_Cliente();
        public Form_GestionVentas()
        {
            InitializeComponent();
        }

        private void Form_GestionVentas_Load(object sender, EventArgs e)
        {

        }

        private void Mostrar()
        {
            dataGridView1.Rows.Clear();
            decimal _totalPagar = 0;
            string _numeroBoleta = txt_NroBoleta.Text;
            bool boletaEncontrada = false;

            foreach (Venta pVenta in _bl_Venta.ObtenerListaVentas())
            {
                if (pVenta.ID.ToString() == _numeroBoleta)
                {
                    boletaEncontrada = true;

                    foreach (Item _item in pVenta.DevolverListaItems())
                    {
                        dataGridView1.Rows.Add(_item.Producto().Nombre.ToString(), _item.Cantidad.ToString(), _item.PrecioUnitario.ToString(), _item.PrecioTotal.ToString());
                        _totalPagar += _item.PrecioTotal;
                    }

                    txt_Fecha.Text = pVenta.Fecha.ToString();
                    txt_DNI.Text = pVenta.Cliente.DNI.ToString();
                    txt_Nombre.Text = pVenta.Cliente.Nombre.ToString();
                    txt_Telefono.Text = pVenta.Cliente.Telefono.ToString();
                    txt_Correo.Text = pVenta.Cliente.Correo.ToString();
                    txt_Total.Text = _totalPagar.ToString();
                }
            }

            if (!boletaEncontrada)
            {
                MessageBox.Show("No se encontró ninguna boleta con el número ingresado.", "Boleta no encontrada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar();
            }
        }

        private void Limpiar()
        {
            dataGridView1.Rows.Clear();
            LimpiarControles(this.Controls);
        }

        private void LimpiarControles(Control.ControlCollection controles)
        {
            foreach (Control c in controles)
            {
                if (c is TextBox)
                    ((TextBox)c).Text = ""; 
                else if (c is GroupBox)
                    LimpiarControles(((GroupBox)c).Controls); 
                else if (c.HasChildren)
                    LimpiarControles(c.Controls);
            }
        }

        private void Btn_BuscarBoleta_Click(object sender, EventArgs e)
        {
            Mostrar();
        }

        private void Btn_limpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void txt_Total_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_NroBoleta.Text == "")
                    throw new Exception("Ingrese el numero de la boleta");
                int _dni = int.Parse(txt_DNI.Text);
                Cliente pCliente = _bl_Cliente.ObtenerCliente(_dni);
                Venta pVenta = _bl_Venta.ObtenerVenta(pCliente);
                DialogResult r = MessageBox.Show("¿Desea eliminar la venta?", "Eliminar Venta", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    _bl_Venta.EliminarVenta(pVenta);
                    MessageBox.Show("Se elimino la venta con exito!");
                    Limpiar();
                }
                else
                    MessageBox.Show("Se cancelo la eliminacion de la venta.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
