﻿namespace Portafolio_1
{
    partial class Form_Venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Editar = new System.Windows.Forms.Button();
            this.Btn_Eliminar = new System.Windows.Forms.Button();
            this.Btn_CancelarVenta = new System.Windows.Forms.Button();
            this.Btn_CrearVenta = new System.Windows.Forms.Button();
            this.Btn_ConfirmarVenta = new System.Windows.Forms.Button();
            this.lb_Vuelto = new System.Windows.Forms.Label();
            this.txt_Vuelto = new System.Windows.Forms.TextBox();
            this.lb_Paga = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio_Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_Pagar = new System.Windows.Forms.TextBox();
            this.lb_TotalPagar = new System.Windows.Forms.Label();
            this.Btn_AgregarItem = new System.Windows.Forms.Button();
            this.txt_TotalPagar = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_BuscarNombre = new System.Windows.Forms.Button();
            this.CantidadItem = new System.Windows.Forms.NumericUpDown();
            this.Lb_Cantidad = new System.Windows.Forms.Label();
            this.lb_Precio = new System.Windows.Forms.Label();
            this.txt_Precio = new System.Windows.Forms.TextBox();
            this.lb_NombreProducto = new System.Windows.Forms.Label();
            this.txt_NombreProducto = new System.Windows.Forms.TextBox();
            this.Btn_BuscarProducto = new System.Windows.Forms.Button();
            this.txt_IDP = new System.Windows.Forms.TextBox();
            this.lb_CodigoProducto = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_BuscarCliente = new System.Windows.Forms.Button();
            this.Lb_NombreCompleto = new System.Windows.Forms.Label();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_DNI = new System.Windows.Forms.TextBox();
            this.Lb_DNI = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CantidadItem)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Editar
            // 
            this.Btn_Editar.Enabled = false;
            this.Btn_Editar.Image = global::Portafolio_1.Properties.Resources.editar_codigo;
            this.Btn_Editar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Editar.Location = new System.Drawing.Point(840, 228);
            this.Btn_Editar.Name = "Btn_Editar";
            this.Btn_Editar.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.Btn_Editar.Size = new System.Drawing.Size(150, 38);
            this.Btn_Editar.TabIndex = 61;
            this.Btn_Editar.Text = "Editar";
            this.Btn_Editar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Editar.UseVisualStyleBackColor = true;
            this.Btn_Editar.Click += new System.EventHandler(this.Btn_Editar_Click);
            // 
            // Btn_Eliminar
            // 
            this.Btn_Eliminar.Enabled = false;
            this.Btn_Eliminar.Image = global::Portafolio_1.Properties.Resources.borrar__1_;
            this.Btn_Eliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Eliminar.Location = new System.Drawing.Point(840, 272);
            this.Btn_Eliminar.Name = "Btn_Eliminar";
            this.Btn_Eliminar.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.Btn_Eliminar.Size = new System.Drawing.Size(150, 38);
            this.Btn_Eliminar.TabIndex = 60;
            this.Btn_Eliminar.Text = "Eliminar";
            this.Btn_Eliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_Eliminar.UseVisualStyleBackColor = true;
            this.Btn_Eliminar.Click += new System.EventHandler(this.Btn_Eliminar_Click);
            // 
            // Btn_CancelarVenta
            // 
            this.Btn_CancelarVenta.Enabled = false;
            this.Btn_CancelarVenta.Image = global::Portafolio_1.Properties.Resources.boton_x;
            this.Btn_CancelarVenta.Location = new System.Drawing.Point(841, 518);
            this.Btn_CancelarVenta.Name = "Btn_CancelarVenta";
            this.Btn_CancelarVenta.Size = new System.Drawing.Size(150, 44);
            this.Btn_CancelarVenta.TabIndex = 59;
            this.Btn_CancelarVenta.Text = "Cancelar Venta";
            this.Btn_CancelarVenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_CancelarVenta.UseVisualStyleBackColor = true;
            this.Btn_CancelarVenta.Click += new System.EventHandler(this.Btn_CancelarVenta_Click);
            // 
            // Btn_CrearVenta
            // 
            this.Btn_CrearVenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_CrearVenta.Location = new System.Drawing.Point(453, 60);
            this.Btn_CrearVenta.Name = "Btn_CrearVenta";
            this.Btn_CrearVenta.Size = new System.Drawing.Size(149, 78);
            this.Btn_CrearVenta.TabIndex = 58;
            this.Btn_CrearVenta.Text = "Crear Venta";
            this.Btn_CrearVenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Btn_CrearVenta.UseCompatibleTextRendering = true;
            this.Btn_CrearVenta.UseVisualStyleBackColor = true;
            this.Btn_CrearVenta.Click += new System.EventHandler(this.Btn_CrearVenta_Click_1);
            // 
            // Btn_ConfirmarVenta
            // 
            this.Btn_ConfirmarVenta.Enabled = false;
            this.Btn_ConfirmarVenta.Image = global::Portafolio_1.Properties.Resources.marcos;
            this.Btn_ConfirmarVenta.Location = new System.Drawing.Point(840, 468);
            this.Btn_ConfirmarVenta.Name = "Btn_ConfirmarVenta";
            this.Btn_ConfirmarVenta.Size = new System.Drawing.Size(150, 44);
            this.Btn_ConfirmarVenta.TabIndex = 57;
            this.Btn_ConfirmarVenta.Text = "Confirmar Venta";
            this.Btn_ConfirmarVenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_ConfirmarVenta.UseVisualStyleBackColor = true;
            this.Btn_ConfirmarVenta.Click += new System.EventHandler(this.Btn_ConfirmarVenta_Click);
            // 
            // lb_Vuelto
            // 
            this.lb_Vuelto.AutoSize = true;
            this.lb_Vuelto.Location = new System.Drawing.Point(843, 416);
            this.lb_Vuelto.Name = "lb_Vuelto";
            this.lb_Vuelto.Size = new System.Drawing.Size(40, 13);
            this.lb_Vuelto.TabIndex = 56;
            this.lb_Vuelto.Text = "Vuelto:";
            // 
            // txt_Vuelto
            // 
            this.txt_Vuelto.Enabled = false;
            this.txt_Vuelto.Location = new System.Drawing.Point(840, 432);
            this.txt_Vuelto.Name = "txt_Vuelto";
            this.txt_Vuelto.Size = new System.Drawing.Size(150, 20);
            this.txt_Vuelto.TabIndex = 55;
            // 
            // lb_Paga
            // 
            this.lb_Paga.AutoSize = true;
            this.lb_Paga.Location = new System.Drawing.Point(843, 371);
            this.lb_Paga.Name = "lb_Paga";
            this.lb_Paga.Size = new System.Drawing.Size(35, 13);
            this.lb_Paga.TabIndex = 54;
            this.lb_Paga.Text = "Paga:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Nombre,
            this.Precio,
            this.Cantidad,
            this.Precio_Total});
            this.dataGridView1.Location = new System.Drawing.Point(16, 244);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(818, 318);
            this.dataGridView1.TabIndex = 50;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            // 
            // Precio
            // 
            this.Precio.HeaderText = "Precio";
            this.Precio.Name = "Precio";
            this.Precio.ReadOnly = true;
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.ReadOnly = true;
            // 
            // Precio_Total
            // 
            this.Precio_Total.HeaderText = "Precio Total";
            this.Precio_Total.Name = "Precio_Total";
            this.Precio_Total.ReadOnly = true;
            // 
            // txt_Pagar
            // 
            this.txt_Pagar.Enabled = false;
            this.txt_Pagar.Location = new System.Drawing.Point(840, 387);
            this.txt_Pagar.Name = "txt_Pagar";
            this.txt_Pagar.Size = new System.Drawing.Size(150, 20);
            this.txt_Pagar.TabIndex = 53;
            this.txt_Pagar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_Pagar_KeyDown);
            // 
            // lb_TotalPagar
            // 
            this.lb_TotalPagar.AutoSize = true;
            this.lb_TotalPagar.Location = new System.Drawing.Point(837, 324);
            this.lb_TotalPagar.Name = "lb_TotalPagar";
            this.lb_TotalPagar.Size = new System.Drawing.Size(73, 13);
            this.lb_TotalPagar.TabIndex = 52;
            this.lb_TotalPagar.Text = "Total a pagar:";
            // 
            // Btn_AgregarItem
            // 
            this.Btn_AgregarItem.Enabled = false;
            this.Btn_AgregarItem.Image = global::Portafolio_1.Properties.Resources.agregar_contacto;
            this.Btn_AgregarItem.Location = new System.Drawing.Point(840, 144);
            this.Btn_AgregarItem.Name = "Btn_AgregarItem";
            this.Btn_AgregarItem.Size = new System.Drawing.Size(149, 78);
            this.Btn_AgregarItem.TabIndex = 49;
            this.Btn_AgregarItem.Text = "Agregar";
            this.Btn_AgregarItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_AgregarItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Btn_AgregarItem.UseCompatibleTextRendering = true;
            this.Btn_AgregarItem.UseVisualStyleBackColor = true;
            this.Btn_AgregarItem.Click += new System.EventHandler(this.Btn_AgregarItem_Click);
            // 
            // txt_TotalPagar
            // 
            this.txt_TotalPagar.Enabled = false;
            this.txt_TotalPagar.Location = new System.Drawing.Point(840, 344);
            this.txt_TotalPagar.Name = "txt_TotalPagar";
            this.txt_TotalPagar.Size = new System.Drawing.Size(150, 20);
            this.txt_TotalPagar.TabIndex = 51;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_BuscarNombre);
            this.groupBox2.Controls.Add(this.CantidadItem);
            this.groupBox2.Controls.Add(this.Lb_Cantidad);
            this.groupBox2.Controls.Add(this.lb_Precio);
            this.groupBox2.Controls.Add(this.txt_Precio);
            this.groupBox2.Controls.Add(this.lb_NombreProducto);
            this.groupBox2.Controls.Add(this.txt_NombreProducto);
            this.groupBox2.Controls.Add(this.Btn_BuscarProducto);
            this.groupBox2.Controls.Add(this.txt_IDP);
            this.groupBox2.Controls.Add(this.lb_CodigoProducto);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(16, 144);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(820, 94);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Información Producto";
            // 
            // Btn_BuscarNombre
            // 
            this.Btn_BuscarNombre.BackColor = System.Drawing.Color.White;
            this.Btn_BuscarNombre.Enabled = false;
            this.Btn_BuscarNombre.ForeColor = System.Drawing.Color.White;
            this.Btn_BuscarNombre.Image = global::Portafolio_1.Properties.Resources.lupa;
            this.Btn_BuscarNombre.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BuscarNombre.Location = new System.Drawing.Point(437, 45);
            this.Btn_BuscarNombre.Name = "Btn_BuscarNombre";
            this.Btn_BuscarNombre.Size = new System.Drawing.Size(43, 28);
            this.Btn_BuscarNombre.TabIndex = 20;
            this.Btn_BuscarNombre.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BuscarNombre.UseVisualStyleBackColor = false;
            this.Btn_BuscarNombre.Click += new System.EventHandler(this.Btn_BuscarNombre_Click);
            // 
            // CantidadItem
            // 
            this.CantidadItem.Enabled = false;
            this.CantidadItem.Location = new System.Drawing.Point(711, 48);
            this.CantidadItem.Name = "CantidadItem";
            this.CantidadItem.Size = new System.Drawing.Size(100, 22);
            this.CantidadItem.TabIndex = 19;
            // 
            // Lb_Cantidad
            // 
            this.Lb_Cantidad.AutoSize = true;
            this.Lb_Cantidad.Enabled = false;
            this.Lb_Cantidad.Location = new System.Drawing.Point(707, 28);
            this.Lb_Cantidad.Name = "Lb_Cantidad";
            this.Lb_Cantidad.Size = new System.Drawing.Size(64, 16);
            this.Lb_Cantidad.TabIndex = 18;
            this.Lb_Cantidad.Text = "Cantidad:";
            // 
            // lb_Precio
            // 
            this.lb_Precio.AutoSize = true;
            this.lb_Precio.Enabled = false;
            this.lb_Precio.Location = new System.Drawing.Point(586, 27);
            this.lb_Precio.Name = "lb_Precio";
            this.lb_Precio.Size = new System.Drawing.Size(49, 16);
            this.lb_Precio.TabIndex = 14;
            this.lb_Precio.Text = "Precio:";
            // 
            // txt_Precio
            // 
            this.txt_Precio.Enabled = false;
            this.txt_Precio.Location = new System.Drawing.Point(589, 47);
            this.txt_Precio.Name = "txt_Precio";
            this.txt_Precio.Size = new System.Drawing.Size(116, 22);
            this.txt_Precio.TabIndex = 13;
            // 
            // lb_NombreProducto
            // 
            this.lb_NombreProducto.AutoSize = true;
            this.lb_NombreProducto.Enabled = false;
            this.lb_NombreProducto.Location = new System.Drawing.Point(228, 28);
            this.lb_NombreProducto.Name = "lb_NombreProducto";
            this.lb_NombreProducto.Size = new System.Drawing.Size(64, 16);
            this.lb_NombreProducto.TabIndex = 12;
            this.lb_NombreProducto.Text = "Producto:";
            // 
            // txt_NombreProducto
            // 
            this.txt_NombreProducto.Enabled = false;
            this.txt_NombreProducto.Location = new System.Drawing.Point(231, 48);
            this.txt_NombreProducto.Name = "txt_NombreProducto";
            this.txt_NombreProducto.Size = new System.Drawing.Size(200, 22);
            this.txt_NombreProducto.TabIndex = 11;
            // 
            // Btn_BuscarProducto
            // 
            this.Btn_BuscarProducto.BackColor = System.Drawing.Color.White;
            this.Btn_BuscarProducto.Enabled = false;
            this.Btn_BuscarProducto.ForeColor = System.Drawing.Color.White;
            this.Btn_BuscarProducto.Image = global::Portafolio_1.Properties.Resources.lupa;
            this.Btn_BuscarProducto.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BuscarProducto.Location = new System.Drawing.Point(182, 45);
            this.Btn_BuscarProducto.Name = "Btn_BuscarProducto";
            this.Btn_BuscarProducto.Size = new System.Drawing.Size(43, 28);
            this.Btn_BuscarProducto.TabIndex = 10;
            this.Btn_BuscarProducto.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BuscarProducto.UseVisualStyleBackColor = false;
            this.Btn_BuscarProducto.Click += new System.EventHandler(this.Btn_BuscarProducto_Click);
            // 
            // txt_IDP
            // 
            this.txt_IDP.Enabled = false;
            this.txt_IDP.Location = new System.Drawing.Point(7, 48);
            this.txt_IDP.Name = "txt_IDP";
            this.txt_IDP.Size = new System.Drawing.Size(169, 22);
            this.txt_IDP.TabIndex = 2;
            // 
            // lb_CodigoProducto
            // 
            this.lb_CodigoProducto.AutoSize = true;
            this.lb_CodigoProducto.Enabled = false;
            this.lb_CodigoProducto.Location = new System.Drawing.Point(6, 28);
            this.lb_CodigoProducto.Name = "lb_CodigoProducto";
            this.lb_CodigoProducto.Size = new System.Drawing.Size(111, 16);
            this.lb_CodigoProducto.TabIndex = 1;
            this.lb_CodigoProducto.Text = "Codigo Producto:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_BuscarCliente);
            this.groupBox1.Controls.Add(this.Lb_NombreCompleto);
            this.groupBox1.Controls.Add(this.txt_Nombre);
            this.groupBox1.Controls.Add(this.txt_DNI);
            this.groupBox1.Controls.Add(this.Lb_DNI);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(431, 87);
            this.groupBox1.TabIndex = 47;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Información Cliente";
            // 
            // Btn_BuscarCliente
            // 
            this.Btn_BuscarCliente.BackColor = System.Drawing.Color.White;
            this.Btn_BuscarCliente.ForeColor = System.Drawing.Color.White;
            this.Btn_BuscarCliente.Image = global::Portafolio_1.Properties.Resources.lupa;
            this.Btn_BuscarCliente.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BuscarCliente.Location = new System.Drawing.Point(182, 45);
            this.Btn_BuscarCliente.Name = "Btn_BuscarCliente";
            this.Btn_BuscarCliente.Size = new System.Drawing.Size(43, 28);
            this.Btn_BuscarCliente.TabIndex = 21;
            this.Btn_BuscarCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BuscarCliente.UseVisualStyleBackColor = false;
            this.Btn_BuscarCliente.Click += new System.EventHandler(this.Btn_BuscarCliente_Click_1);
            // 
            // Lb_NombreCompleto
            // 
            this.Lb_NombreCompleto.AutoSize = true;
            this.Lb_NombreCompleto.Location = new System.Drawing.Point(228, 28);
            this.Lb_NombreCompleto.Name = "Lb_NombreCompleto";
            this.Lb_NombreCompleto.Size = new System.Drawing.Size(120, 16);
            this.Lb_NombreCompleto.TabIndex = 12;
            this.Lb_NombreCompleto.Text = "Nombre Completo:";
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Location = new System.Drawing.Point(231, 48);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(194, 22);
            this.txt_Nombre.TabIndex = 11;
            // 
            // txt_DNI
            // 
            this.txt_DNI.Location = new System.Drawing.Point(7, 48);
            this.txt_DNI.Name = "txt_DNI";
            this.txt_DNI.Size = new System.Drawing.Size(169, 22);
            this.txt_DNI.TabIndex = 2;
            // 
            // Lb_DNI
            // 
            this.Lb_DNI.AutoSize = true;
            this.Lb_DNI.Location = new System.Drawing.Point(6, 28);
            this.Lb_DNI.Name = "Lb_DNI";
            this.Lb_DNI.Size = new System.Drawing.Size(104, 16);
            this.Lb_DNI.TabIndex = 1;
            this.Lb_DNI.Text = "Nro Documento:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 26);
            this.label1.TabIndex = 46;
            this.label1.Text = "Registrar Venta";
            // 
            // Form_Venta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 572);
            this.Controls.Add(this.Btn_Editar);
            this.Controls.Add(this.Btn_Eliminar);
            this.Controls.Add(this.Btn_CancelarVenta);
            this.Controls.Add(this.Btn_CrearVenta);
            this.Controls.Add(this.Btn_ConfirmarVenta);
            this.Controls.Add(this.lb_Vuelto);
            this.Controls.Add(this.txt_Vuelto);
            this.Controls.Add(this.lb_Paga);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_Pagar);
            this.Controls.Add(this.lb_TotalPagar);
            this.Controls.Add(this.Btn_AgregarItem);
            this.Controls.Add(this.txt_TotalPagar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form_Venta";
            this.Text = "Form_Venta";
            this.Load += new System.EventHandler(this.Form_Venta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CantidadItem)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Editar;
        private System.Windows.Forms.Button Btn_Eliminar;
        private System.Windows.Forms.Button Btn_CancelarVenta;
        private System.Windows.Forms.Button Btn_CrearVenta;
        private System.Windows.Forms.Button Btn_ConfirmarVenta;
        private System.Windows.Forms.Label lb_Vuelto;
        private System.Windows.Forms.TextBox txt_Vuelto;
        private System.Windows.Forms.Label lb_Paga;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Precio;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Precio_Total;
        private System.Windows.Forms.TextBox txt_Pagar;
        private System.Windows.Forms.Label lb_TotalPagar;
        private System.Windows.Forms.Button Btn_AgregarItem;
        private System.Windows.Forms.TextBox txt_TotalPagar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_BuscarNombre;
        private System.Windows.Forms.NumericUpDown CantidadItem;
        private System.Windows.Forms.Label Lb_Cantidad;
        private System.Windows.Forms.Label lb_Precio;
        private System.Windows.Forms.TextBox txt_Precio;
        private System.Windows.Forms.Label lb_NombreProducto;
        private System.Windows.Forms.TextBox txt_NombreProducto;
        private System.Windows.Forms.Button Btn_BuscarProducto;
        private System.Windows.Forms.TextBox txt_IDP;
        private System.Windows.Forms.Label lb_CodigoProducto;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_BuscarCliente;
        private System.Windows.Forms.Label Lb_NombreCompleto;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_DNI;
        private System.Windows.Forms.Label Lb_DNI;
        private System.Windows.Forms.Label label1;
    }
}