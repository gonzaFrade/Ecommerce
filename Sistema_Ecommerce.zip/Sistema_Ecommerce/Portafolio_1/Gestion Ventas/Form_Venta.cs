﻿using BE;
using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using Microsoft.VisualBasic;
using Portafolio_1.Properties;

namespace Portafolio_1
{
    public partial class Form_Venta : Form
    {
        BLL_Cliente _bl_Cliente = new BLL_Cliente();
        BLL_Producto _bl_Producto = new BLL_Producto();
        private Venta venta;
        BLL_Venta _bl_Venta = new BLL_Venta();
        int _telefono = 0;
        string _correo;
        BLL_Item _bl_Item = new BLL_Item();
        public Form_Venta()
        {
            InitializeComponent();
        }

        private void Form_Venta_Load(object sender, EventArgs e)
        {

        }
        private void Btn_BuscarCliente_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txt_DNI.Text))
                    throw new Exception("Para buscar al cliente ingrese el DNI del mismo");

                string _dni = txt_DNI.Text;

                if (_bl_Cliente.ObtenerClientes().Exists(x => x.DNI.ToString() == _dni))
                {
                    Cliente pCliente = _bl_Cliente.ObtenerCliente(int.Parse(_dni));
                    txt_Nombre.Text = pCliente.Nombre;
                    _telefono = pCliente.Telefono;
                    _correo = pCliente.Correo;
                }
                else
                {
                    txt_Nombre.Text = "";
                    throw new Exception("No hay ningun cliente con este DNI");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_CrearVenta_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (txt_DNI.Text == "" && txt_Nombre.Text == "")
                    throw new Exception("Para crear una venta, ingrese el DNI y el Nombre del cliente!");
                Cliente pCliente = new Cliente(int.Parse(txt_DNI.Text), txt_Nombre.Text, _telefono, _correo);

                if (_bl_Venta.ObtenerTodasListaVentas().Count == 0)
                {
                    venta = new Venta(1, pCliente, DateTime.Now);
                    HabilitarBotones();
                }
                else
                {
                    int _id = _bl_Venta.ObtenerTodasListaVentas().Last().ID + 1;
                    venta = new Venta(_id, pCliente, DateTime.Now);
                    HabilitarBotones();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void HabilitarBotones()
        {
            txt_IDP.Enabled = true;
            txt_NombreProducto.Enabled = true;
            CantidadItem.Enabled = true;
            Btn_AgregarItem.Enabled = true;
            txt_DNI.Enabled = false;
            txt_Nombre.Enabled = false;
            txt_Pagar.Enabled = true;
            Btn_ConfirmarVenta.Enabled = true;
            Btn_BuscarProducto.Enabled = true;
            lb_CodigoProducto.Enabled = true;
            Btn_BuscarNombre.Enabled = true;
            lb_NombreProducto.Enabled = true;
            lb_Precio.Enabled = true;
            Btn_CrearVenta.Enabled = false;
            lb_TotalPagar.Enabled = true;
            lb_Paga.Enabled = true;
            lb_Vuelto.Enabled = true;
            Btn_BuscarCliente.Enabled = false;
            Lb_Cantidad.Enabled = true;
            Btn_CancelarVenta.Enabled = true;
            Btn_Eliminar.Enabled = true;
            Btn_Editar.Enabled = true;
        }

        private void Mostrar_Venta()
        {
            dataGridView1.Rows.Clear();
            decimal _totalPagar = 0;

            foreach (Item item in venta.DevolverListaItems())
            {
                dataGridView1.Rows.Add(item.Producto().ID, item.Producto().Nombre.ToString(), item.PrecioUnitario.ToString(), item.Cantidad.ToString(), item.PrecioTotal.ToString());
                _totalPagar += item.PrecioTotal;
            }

            txt_TotalPagar.Text = _totalPagar.ToString();
            if (dataGridView1.Rows.Count >= 1)
                this.dataGridView1.CurrentRow.Selected = false;
        }


        private void CalcularVuelto()
        {
            if (txt_TotalPagar.Text.Trim() == "")
            {
                MessageBox.Show("No existen productos en la venta!", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            decimal _paga;
            decimal _total = Convert.ToDecimal(txt_TotalPagar.Text);

            if (txt_Pagar.Text.Trim() == "")
                txt_Pagar.Text = "0";

            if (decimal.TryParse(txt_Pagar.Text.Trim(), out _paga))
            {
                if (_paga < _total)
                    txt_Vuelto.Text = "Error";
                else
                {
                    decimal _cambio = _paga - _total;
                    txt_Vuelto.Text = _cambio.ToString("0.00");
                }
            }
        }

        private void txt_Pagar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                CalcularVuelto();
        }

        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0)
                    throw new Exception("Necesitas agregar productos a la compra para eliminar!");

                if (dataGridView1.SelectedRows[0].Selected == false)
                    throw new Exception("Seleccione un producto para eliminar!");

                DialogResult r = MessageBox.Show("¿Desea eliminar el producto?", "Eliminar producto", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    Item pItem = venta.DevolverListaItems().Find(x => x.Producto().ID == int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
                    venta.DevolverListaItems().Remove(pItem);
                    txt_IDP.Text = "";
                    txt_NombreProducto.Text = "";
                    txt_Precio.Text = "";
                    CantidadItem.Value = 1;
                    Mostrar_Venta();
                }
                else
                    MessageBox.Show("Se cancelo la eliminacion del producto");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_CancelarVenta_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult r = MessageBox.Show("¿Desea cancelar la venta?", "Cancelar Venta", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    if (dataGridView1.Rows.Count != 0)
                        venta.DevolverListaItems().Clear();
                    MessageBox.Show("La venta ha sido cancelada");
                    Mostrar_Venta();
                    HabilitarCancelar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void HabilitarCancelar()
        {
            Lb_DNI.Enabled = true;
            txt_DNI.Enabled = true;
            Btn_BuscarCliente.Enabled = true;
            txt_Nombre.Enabled = true;
            Lb_NombreCompleto.Enabled = true;
            Btn_CrearVenta.Enabled = true;
            lb_CodigoProducto.Enabled = false;
            txt_IDP.Enabled = false;
            Btn_BuscarProducto.Enabled = false;
            lb_NombreProducto.Enabled = false;
            txt_NombreProducto.Enabled = false;
            Btn_BuscarNombre.Enabled = false;
            lb_Precio.Enabled = false;
            txt_Precio.Enabled = false;
            Lb_Cantidad.Enabled = false;
            CantidadItem.Enabled = false;
            Btn_AgregarItem.Enabled = false;
            Btn_Eliminar.Enabled = false;
            lb_TotalPagar.Enabled = false;
            txt_TotalPagar.Enabled = false;
            lb_Paga.Enabled = false;
            txt_Pagar.Enabled = false;
            lb_Vuelto.Enabled = false;
            txt_Vuelto.Enabled = false;
            Btn_ConfirmarVenta.Enabled = false;
            Btn_CancelarVenta.Enabled = false;
            Btn_Editar.Enabled = false;
        }

        private void Btn_AgregarItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_IDP.Text == "" && txt_NombreProducto.Text == "" && txt_Precio.Text == "")
                    throw new Exception("Para agregar un producto rellene los casilleros del producto");

                Producto pProducto = _bl_Producto.ObtenerProducto(int.Parse(txt_IDP.Text));
                Item pItem = null;

                foreach (Item x in venta.DevolverListaItems())
                {
                    if (x.Producto().ID == pProducto.ID)
                    {
                        int _cantidad = x.Cantidad + int.Parse(CantidadItem.Value.ToString());
                        x.Cantidad = _cantidad;
                        venta.EditarItem(x);
                        pItem = x;
                        txt_IDP.Text = "";
                        txt_NombreProducto.Text = "";
                        txt_Precio.Text = "";
                        CantidadItem.Value = 1;
                        break;
                    }
                }

                if (pItem == null)
                {
                    pItem = new Item(pProducto, venta, int.Parse(CantidadItem.Value.ToString()));
                    venta.AgregarItem(pItem);
                    txt_IDP.Text = "";
                    txt_NombreProducto.Text = "";
                    txt_Precio.Text = "";
                    CantidadItem.Value = 1;
                }

                Mostrar_Venta();
                this.dataGridView1.CurrentRow.Selected = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Editar_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0)
                    throw new Exception("Necesitas agregar productos a la compra para editar!");

                if (dataGridView1.SelectedRows[0].Selected == false)
                    throw new Exception("Seleccione un producto para editar!");

                Item pItem = venta.DevolverListaItems().Find(x => x.Producto().ID == int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString()));
                DialogResult r = MessageBox.Show("¿Desea editar el producto?", "Editar producto", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    string _cantidad = CantidadItem.Value.ToString();
                    pItem.Cantidad = int.Parse(_cantidad);
                    venta.EditarItem(pItem);
                    CantidadItem.Value = 1;
                    Mostrar_Venta();
                    txt_NombreProducto.Text = "";
                    txt_IDP.Text = "";
                    txt_Precio.Text = "";
                    this.dataGridView1.CurrentRow.Selected = false;
                }
                else
                    MessageBox.Show("Se cancelo la edicion del producto!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_ConfirmarVenta_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    DialogResult r = MessageBox.Show("¿Desea confirmar la venta?", "Confirmar Venta", MessageBoxButtons.YesNo);

                    if (r == DialogResult.Yes)
                    {
                        _bl_Venta.AgregarVenta(venta);
                        foreach (Item pItem in venta.DevolverListaItems())
                            _bl_Item.AgregarItem(pItem);

                        SaveFileDialog guardar = new SaveFileDialog();
                        guardar.FileName = $"{venta.Cliente.Nombre}.{DateTime.Now.ToString("dd.MM.yyyy.HH.mm.ss")}.pdf";
                        guardar.ShowDialog();
                        string paginahtml_texto = Properties.Resources.plantilla;
                        paginahtml_texto = paginahtml_texto.Replace("@CLIENTE", $"{venta.Cliente.Nombre}");
                        paginahtml_texto = paginahtml_texto.Replace("@DOCUMENTO", $"{venta.Cliente.DNI}");
                        paginahtml_texto = paginahtml_texto.Replace("@FECHA", DateTime.Now.ToString("dd/MM/yyyy"));
                        paginahtml_texto = paginahtml_texto.Replace("@ID", venta.ID.ToString());
                        string filas = string.Empty;
                        decimal _total = 0;
                        dataGridView1.Rows.Clear();

                        foreach (Item _item in venta.DevolverListaItems())
                        {
                            venta.PrecioTotal += _item.Producto().Precio * _item.Cantidad;
                            dataGridView1.Rows.Add(venta.ID.ToString(), _item.Producto().Nombre.ToString(), _item.Cantidad.ToString(), _item.Producto().Precio.ToString(), _item.PrecioTotal.ToString());
                        }

                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            if (row.IsNewRow == false)
                            {
                                filas += "<tr>";
                                filas += "<td>" + row.Cells["Nombre"].Value.ToString() + "</td>";
                                filas += "<td>" + row.Cells["Precio"].Value.ToString() + "</td>";
                                filas += "<td>" + row.Cells["Cantidad"].Value.ToString() + "</td>";
                                filas += "<td>" + row.Cells["Precio_Total"].Value.ToString() + "</td>";
                                filas += "</tr>";
                                _total += decimal.Parse(row.Cells["Precio_Total"].Value.ToString());
                            }
                        }

                        paginahtml_texto = paginahtml_texto.Replace("@FILAS", filas);
                        paginahtml_texto = paginahtml_texto.Replace("@TOTAL", _total.ToString());
                        if (guardar.ShowDialog() == DialogResult.OK)
                        {
                            string tempFilePath = Path.GetTempFileName() + ".png";
                            try
                            {
                                byte[] imgBytes = (byte[])new ImageConverter().ConvertTo(Properties.Resources._0801229dd50e7d4c15642b4490082957, typeof(byte[]));
                                File.WriteAllBytes(tempFilePath, imgBytes);
                                using (FileStream stream = new FileStream(guardar.FileName, FileMode.Create))
                                {
                                    Document pdfDoc = new Document(PageSize.A4, 25, 25, 25, 25);
                                    PdfWriter escribir = PdfWriter.GetInstance(pdfDoc, stream);
                                    pdfDoc.Open();
                                    pdfDoc.Add(new Phrase(""));
                                    iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(tempFilePath);
                                    img.ScaleToFit(98, 80);
                                    img.SetAbsolutePosition(pdfDoc.LeftMargin, pdfDoc.PageSize.Height - 100);
                                    pdfDoc.Add(img);

                                    using (StringReader sr = new StringReader(paginahtml_texto))
                                    {
                                        XMLWorkerHelper.GetInstance().ParseXHtml(escribir, pdfDoc, sr);
                                    }

                                    pdfDoc.Close();
                                }
                            }
                            finally
                            {
                                if (File.Exists(tempFilePath))
                                    File.Delete(tempFilePath);
                            }
                        }
                    }

                    this.Close();
                }
                else
                    MessageBox.Show("Se necesita agregar productos a la venta para confirmarla!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_NombreProducto.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txt_IDP.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txt_Precio.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void Btn_BuscarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txt_IDP.Text))
                    throw new Exception("Para buscar el producto ingrese un ID");

                string _id = txt_IDP.Text;

                if (_bl_Producto.ObtenerListaProductos().Exists(x => x.ID.ToString() == _id))
                {
                    Producto pProducto = _bl_Producto.ObtenerProducto(int.Parse(_id));
                    txt_NombreProducto.Text = pProducto.Nombre;
                    txt_Precio.Text = pProducto.Precio.ToString();
                }
                else
                {
                    txt_NombreProducto.Text = "";
                    _telefono = 0;
                    _correo = "";
                    throw new Exception("No hay ningun producto con esta ID");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_BuscarNombre_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txt_NombreProducto.Text))
                    throw new Exception("Para buscar el producto ingrese el nombre del mismo");

                string _nombre = txt_NombreProducto.Text;

                if (_bl_Producto.ObtenerListaProductos().Exists(x => x.Nombre.ToString() == _nombre))
                {
                    foreach (var x in _bl_Producto.ObtenerListaProductos())
                    {
                        if (x.Nombre == _nombre)
                        {
                            txt_IDP.Text = x.ID.ToString();
                            txt_Precio.Text = x.Precio.ToString();
                        }
                    }
                }
                else
                {
                    txt_IDP.Text = "";
                    throw new Exception("No hay ningun producto con este nombre");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
