﻿using Portafolio_1.Gestion_Producto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Portafolio_1
{
    public partial class Pantalla_Inicial : Form
    {

        private static ToolStripMenuItem MenuActivo = null;
        private static Form FormularioActivo = null;
        public Pantalla_Inicial()
        {
            InitializeComponent();
        }

        private void Pantalla_Inicial_Load(object sender, EventArgs e)
        {

        }
        
        private void AbrirFormulario(ToolStripMenuItem menu,Form Formulario)
        {
            if (MenuActivo != null)
            {
                MenuActivo.BackColor = Color.White;
            }
            menu.BackColor = Color.Silver;
            MenuActivo = menu;

            if (FormularioActivo != null)
            {
                FormularioActivo.Close();
            }

            FormularioActivo = Formulario;
            Formulario.TopLevel = false;
            Formulario.FormBorderStyle = FormBorderStyle.None;
            Formulario.Dock = DockStyle.Fill;
            Formulario.BackColor = Color.White;

            contenedor.Controls.Add(Formulario);
            Formulario.Show();

        }

        private void ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AbrirFormulario((ToolStripMenuItem)sender, new Form_GestionClientes());
        }

        private void ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            AbrirFormulario((ToolStripMenuItem)sender, new Form_GestionProductos());
        }

        private void RealizarVentaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormulario((ToolStripMenuItem)sender, new Form_Venta());
        }

        private void GestionarVentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormulario((ToolStripMenuItem)sender, new Form_GestionVentas());
        }

        private void ReportesMensualesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormulario((ToolStripMenuItem)sender, new Form_ReporteProducto());
        }

        private void SalirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
