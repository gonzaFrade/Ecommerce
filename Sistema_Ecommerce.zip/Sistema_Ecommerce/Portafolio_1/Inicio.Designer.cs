﻿namespace Portafolio_1
{
    partial class Pantalla_Inicial
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label1 = new System.Windows.Forms.Label();
            this.contenedor = new System.Windows.Forms.Panel();
            this.MenuStrip2 = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.VentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RealizarVentaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GestionarVentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportesMensualesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.SalirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.SteelBlue;
            this.Label1.Font = new System.Drawing.Font("Verdana", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.White;
            this.Label1.Location = new System.Drawing.Point(12, 20);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(266, 32);
            this.Label1.TabIndex = 7;
            this.Label1.Text = "Sistema de Ventas";
            // 
            // contenedor
            // 
            this.contenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contenedor.Location = new System.Drawing.Point(0, 135);
            this.contenedor.Name = "contenedor";
            this.contenedor.Size = new System.Drawing.Size(1014, 566);
            this.contenedor.TabIndex = 6;
            // 
            // MenuStrip2
            // 
            this.MenuStrip2.AutoSize = false;
            this.MenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem1,
            this.ToolStripMenuItem2,
            this.VentasToolStripMenuItem,
            this.ReportesMensualesToolStripMenuItem,
            this.ToolStripMenuItem3,
            this.SalirToolStripMenuItem});
            this.MenuStrip2.Location = new System.Drawing.Point(0, 72);
            this.MenuStrip2.Name = "MenuStrip2";
            this.MenuStrip2.Size = new System.Drawing.Size(1014, 63);
            this.MenuStrip2.TabIndex = 5;
            this.MenuStrip2.Text = "MenuStrip2";
            // 
            // ToolStripMenuItem1
            // 
            this.ToolStripMenuItem1.AutoSize = false;
            this.ToolStripMenuItem1.Image = global::Portafolio_1.Properties.Resources.business_application_addmale_useradd_insert_add_user_client_2312;
            this.ToolStripMenuItem1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            this.ToolStripMenuItem1.Size = new System.Drawing.Size(104, 59);
            this.ToolStripMenuItem1.Text = "Gestion Clientes";
            this.ToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ToolStripMenuItem1.Click += new System.EventHandler(this.ToolStripMenuItem1_Click);
            // 
            // ToolStripMenuItem2
            // 
            this.ToolStripMenuItem2.AutoSize = false;
            this.ToolStripMenuItem2.Image = global::Portafolio_1.Properties.Resources.warehouse_storage_unit_storehouse_icon_192428;
            this.ToolStripMenuItem2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            this.ToolStripMenuItem2.Size = new System.Drawing.Size(116, 59);
            this.ToolStripMenuItem2.Text = "Gestion productos";
            this.ToolStripMenuItem2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ToolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ToolStripMenuItem2.Click += new System.EventHandler(this.ToolStripMenuItem2_Click);
            // 
            // VentasToolStripMenuItem
            // 
            this.VentasToolStripMenuItem.AutoSize = false;
            this.VentasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RealizarVentaToolStripMenuItem,
            this.GestionarVentasToolStripMenuItem});
            this.VentasToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VentasToolStripMenuItem.Image = global::Portafolio_1.Properties.Resources.carro_de_la_carretilla;
            this.VentasToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.VentasToolStripMenuItem.Name = "VentasToolStripMenuItem";
            this.VentasToolStripMenuItem.Size = new System.Drawing.Size(122, 59);
            this.VentasToolStripMenuItem.Text = "Ventas";
            this.VentasToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.VentasToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // RealizarVentaToolStripMenuItem
            // 
            this.RealizarVentaToolStripMenuItem.Name = "RealizarVentaToolStripMenuItem";
            this.RealizarVentaToolStripMenuItem.Size = new System.Drawing.Size(188, 24);
            this.RealizarVentaToolStripMenuItem.Text = "Realizar Venta";
            this.RealizarVentaToolStripMenuItem.Click += new System.EventHandler(this.RealizarVentaToolStripMenuItem_Click);
            // 
            // GestionarVentasToolStripMenuItem
            // 
            this.GestionarVentasToolStripMenuItem.Name = "GestionarVentasToolStripMenuItem";
            this.GestionarVentasToolStripMenuItem.Size = new System.Drawing.Size(188, 24);
            this.GestionarVentasToolStripMenuItem.Text = "Gestionar Ventas";
            this.GestionarVentasToolStripMenuItem.Click += new System.EventHandler(this.GestionarVentasToolStripMenuItem_Click);
            // 
            // ReportesMensualesToolStripMenuItem
            // 
            this.ReportesMensualesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportesMensualesToolStripMenuItem.Image = global::Portafolio_1.Properties.Resources.reporte_de_negocios;
            this.ReportesMensualesToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ReportesMensualesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ReportesMensualesToolStripMenuItem.Name = "ReportesMensualesToolStripMenuItem";
            this.ReportesMensualesToolStripMenuItem.Size = new System.Drawing.Size(139, 59);
            this.ReportesMensualesToolStripMenuItem.Text = "Reportes Mensuales";
            this.ReportesMensualesToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ReportesMensualesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ReportesMensualesToolStripMenuItem.Click += new System.EventHandler(this.ReportesMensualesToolStripMenuItem_Click);
            // 
            // ToolStripMenuItem3
            // 
            this.ToolStripMenuItem3.BackColor = System.Drawing.Color.Transparent;
            this.ToolStripMenuItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.ToolStripMenuItem3.Enabled = false;
            this.ToolStripMenuItem3.Name = "ToolStripMenuItem3";
            this.ToolStripMenuItem3.Padding = new System.Windows.Forms.Padding(4, 0, 445, 0);
            this.ToolStripMenuItem3.Size = new System.Drawing.Size(453, 59);
            // 
            // SalirToolStripMenuItem
            // 
            this.SalirToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalirToolStripMenuItem.Image = global::Portafolio_1.Properties.Resources.salida;
            this.SalirToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem";
            this.SalirToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 0, 20, 0);
            this.SalirToolStripMenuItem.Size = new System.Drawing.Size(61, 59);
            this.SalirToolStripMenuItem.Text = "Salir";
            this.SalirToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SalirToolStripMenuItem.Click += new System.EventHandler(this.SalirToolStripMenuItem_Click);
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.AutoSize = false;
            this.MenuStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.MenuStrip1.Size = new System.Drawing.Size(1014, 72);
            this.MenuStrip1.TabIndex = 4;
            // 
            // Pantalla_Inicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1014, 701);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.contenedor);
            this.Controls.Add(this.MenuStrip2);
            this.Controls.Add(this.MenuStrip1);
            this.Name = "Pantalla_Inicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pantalla Inicial";
            this.Load += new System.EventHandler(this.Pantalla_Inicial_Load);
            this.MenuStrip2.ResumeLayout(false);
            this.MenuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Panel contenedor;
        internal System.Windows.Forms.MenuStrip MenuStrip2;
        internal System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem2;
        internal System.Windows.Forms.ToolStripMenuItem VentasToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem RealizarVentaToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem GestionarVentasToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem ReportesMensualesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem3;
        internal System.Windows.Forms.ToolStripMenuItem SalirToolStripMenuItem;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
    }
}

