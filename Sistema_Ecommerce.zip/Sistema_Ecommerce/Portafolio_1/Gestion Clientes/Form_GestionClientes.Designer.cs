﻿namespace Portafolio_1
{
    partial class Form_GestionClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.Btn_LimpiarTxt = new System.Windows.Forms.Button();
            this.Btn_BuscarFiltro = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lb_GestionClientes = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_BorrarDetalles = new System.Windows.Forms.Button();
            this.btn_Registrar = new System.Windows.Forms.Button();
            this.Btn_EditarCliente = new System.Windows.Forms.Button();
            this.Btn_EliminarCliente = new System.Windows.Forms.Button();
            this.txt_Correo = new System.Windows.Forms.TextBox();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_DNI = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.DNI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre_Completo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_LimpiarTxt
            // 
            this.Btn_LimpiarTxt.BackColor = System.Drawing.Color.White;
            this.Btn_LimpiarTxt.ForeColor = System.Drawing.Color.White;
            this.Btn_LimpiarTxt.Image = global::Portafolio_1.Properties.Resources.borrador;
            this.Btn_LimpiarTxt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_LimpiarTxt.Location = new System.Drawing.Point(934, 66);
            this.Btn_LimpiarTxt.Name = "Btn_LimpiarTxt";
            this.Btn_LimpiarTxt.Size = new System.Drawing.Size(47, 28);
            this.Btn_LimpiarTxt.TabIndex = 26;
            this.Btn_LimpiarTxt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_LimpiarTxt.UseVisualStyleBackColor = false;
            this.Btn_LimpiarTxt.Click += new System.EventHandler(this.Btn_LimpiarTxt_Click);
            // 
            // Btn_BuscarFiltro
            // 
            this.Btn_BuscarFiltro.BackColor = System.Drawing.Color.White;
            this.Btn_BuscarFiltro.ForeColor = System.Drawing.Color.White;
            this.Btn_BuscarFiltro.Image = global::Portafolio_1.Properties.Resources.lupa;
            this.Btn_BuscarFiltro.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BuscarFiltro.Location = new System.Drawing.Point(881, 66);
            this.Btn_BuscarFiltro.Name = "Btn_BuscarFiltro";
            this.Btn_BuscarFiltro.Size = new System.Drawing.Size(47, 28);
            this.Btn_BuscarFiltro.TabIndex = 25;
            this.Btn_BuscarFiltro.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BuscarFiltro.UseVisualStyleBackColor = false;
            this.Btn_BuscarFiltro.Click += new System.EventHandler(this.Btn_BuscarFiltro_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(554, 70);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(118, 21);
            this.comboBox1.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(487, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Buscar por:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(678, 70);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(198, 20);
            this.textBox5.TabIndex = 22;
            // 
            // lb_GestionClientes
            // 
            this.lb_GestionClientes.AutoSize = true;
            this.lb_GestionClientes.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_GestionClientes.Location = new System.Drawing.Point(281, 64);
            this.lb_GestionClientes.Name = "lb_GestionClientes";
            this.lb_GestionClientes.Size = new System.Drawing.Size(190, 26);
            this.lb_GestionClientes.TabIndex = 21;
            this.lb_GestionClientes.Text = "Gestion Clientes";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_BorrarDetalles);
            this.groupBox1.Controls.Add(this.btn_Registrar);
            this.groupBox1.Controls.Add(this.Btn_EditarCliente);
            this.groupBox1.Controls.Add(this.Btn_EliminarCliente);
            this.groupBox1.Controls.Add(this.txt_Correo);
            this.groupBox1.Controls.Add(this.txt_Telefono);
            this.groupBox1.Controls.Add(this.txt_Nombre);
            this.groupBox1.Controls.Add(this.txt_DNI);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(263, 501);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            // 
            // Btn_BorrarDetalles
            // 
            this.Btn_BorrarDetalles.BackColor = System.Drawing.Color.White;
            this.Btn_BorrarDetalles.ForeColor = System.Drawing.Color.White;
            this.Btn_BorrarDetalles.Image = global::Portafolio_1.Properties.Resources.borrador;
            this.Btn_BorrarDetalles.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Btn_BorrarDetalles.Location = new System.Drawing.Point(226, 13);
            this.Btn_BorrarDetalles.Name = "Btn_BorrarDetalles";
            this.Btn_BorrarDetalles.Size = new System.Drawing.Size(31, 28);
            this.Btn_BorrarDetalles.TabIndex = 19;
            this.Btn_BorrarDetalles.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_BorrarDetalles.UseVisualStyleBackColor = false;
            this.Btn_BorrarDetalles.Click += new System.EventHandler(this.Btn_BorrarDetalles_Click_1);
            // 
            // btn_Registrar
            // 
            this.btn_Registrar.BackColor = System.Drawing.Color.ForestGreen;
            this.btn_Registrar.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Registrar.ForeColor = System.Drawing.Color.White;
            this.btn_Registrar.Image = global::Portafolio_1.Properties.Resources.icons8_guardar_241;
            this.btn_Registrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Registrar.Location = new System.Drawing.Point(14, 338);
            this.btn_Registrar.Name = "btn_Registrar";
            this.btn_Registrar.Padding = new System.Windows.Forms.Padding(50, 0, 28, 0);
            this.btn_Registrar.Size = new System.Drawing.Size(241, 47);
            this.btn_Registrar.TabIndex = 14;
            this.btn_Registrar.Text = "Registrar";
            this.btn_Registrar.UseVisualStyleBackColor = false;
            this.btn_Registrar.Click += new System.EventHandler(this.btn_Registrar_Click_1);
            // 
            // Btn_EditarCliente
            // 
            this.Btn_EditarCliente.BackColor = System.Drawing.Color.DodgerBlue;
            this.Btn_EditarCliente.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_EditarCliente.ForeColor = System.Drawing.Color.White;
            this.Btn_EditarCliente.Image = global::Portafolio_1.Properties.Resources.icons8_editar_16;
            this.Btn_EditarCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_EditarCliente.Location = new System.Drawing.Point(14, 391);
            this.Btn_EditarCliente.Name = "Btn_EditarCliente";
            this.Btn_EditarCliente.Padding = new System.Windows.Forms.Padding(55, 0, 40, 0);
            this.Btn_EditarCliente.Size = new System.Drawing.Size(241, 47);
            this.Btn_EditarCliente.TabIndex = 13;
            this.Btn_EditarCliente.Text = "Editar";
            this.Btn_EditarCliente.UseVisualStyleBackColor = false;
            this.Btn_EditarCliente.Click += new System.EventHandler(this.Btn_EditarCliente_Click);
            // 
            // Btn_EliminarCliente
            // 
            this.Btn_EliminarCliente.BackColor = System.Drawing.Color.Red;
            this.Btn_EliminarCliente.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_EliminarCliente.ForeColor = System.Drawing.Color.White;
            this.Btn_EliminarCliente.Image = global::Portafolio_1.Properties.Resources.icons8_eliminar_16;
            this.Btn_EliminarCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_EliminarCliente.Location = new System.Drawing.Point(14, 444);
            this.Btn_EliminarCliente.Name = "Btn_EliminarCliente";
            this.Btn_EliminarCliente.Padding = new System.Windows.Forms.Padding(55, 0, 40, 0);
            this.Btn_EliminarCliente.Size = new System.Drawing.Size(241, 47);
            this.Btn_EliminarCliente.TabIndex = 14;
            this.Btn_EliminarCliente.Text = "Eliminar";
            this.Btn_EliminarCliente.UseVisualStyleBackColor = false;
            this.Btn_EliminarCliente.Click += new System.EventHandler(this.Btn_EliminarCliente_Click);
            // 
            // txt_Correo
            // 
            this.txt_Correo.Location = new System.Drawing.Point(16, 287);
            this.txt_Correo.Name = "txt_Correo";
            this.txt_Correo.Size = new System.Drawing.Size(241, 20);
            this.txt_Correo.TabIndex = 12;
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Location = new System.Drawing.Point(16, 218);
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(241, 20);
            this.txt_Telefono.TabIndex = 11;
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Location = new System.Drawing.Point(13, 148);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(245, 20);
            this.txt_Nombre.TabIndex = 10;
            // 
            // txt_DNI
            // 
            this.txt_DNI.Location = new System.Drawing.Point(13, 76);
            this.txt_DNI.Name = "txt_DNI";
            this.txt_DNI.Size = new System.Drawing.Size(244, 20);
            this.txt_DNI.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Correo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nro Telefono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nombre Completo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Book Antiqua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nro de Documento:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Detalle del Cliente";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DNI,
            this.Nombre_Completo,
            this.Telefono,
            this.Correo});
            this.dataGridView1.Location = new System.Drawing.Point(286, 107);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(704, 443);
            this.dataGridView1.TabIndex = 19;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick_1);
            // 
            // DNI
            // 
            this.DNI.HeaderText = "DNI";
            this.DNI.Name = "DNI";
            this.DNI.ReadOnly = true;
            // 
            // Nombre_Completo
            // 
            this.Nombre_Completo.HeaderText = "Nombre Completo";
            this.Nombre_Completo.Name = "Nombre_Completo";
            this.Nombre_Completo.ReadOnly = true;
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            this.Telefono.ReadOnly = true;
            // 
            // Correo
            // 
            this.Correo.HeaderText = "Correo";
            this.Correo.Name = "Correo";
            this.Correo.ReadOnly = true;
            // 
            // Form_GestionClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 572);
            this.Controls.Add(this.Btn_LimpiarTxt);
            this.Controls.Add(this.Btn_BuscarFiltro);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lb_GestionClientes);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form_GestionClientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_Clientes";
            this.Load += new System.EventHandler(this.Form_GestionClientes_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button Btn_LimpiarTxt;
        private System.Windows.Forms.Button Btn_BuscarFiltro;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lb_GestionClientes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_BorrarDetalles;
        private System.Windows.Forms.Button btn_Registrar;
        private System.Windows.Forms.Button Btn_EditarCliente;
        private System.Windows.Forms.Button Btn_EliminarCliente;
        private System.Windows.Forms.TextBox txt_Correo;
        private System.Windows.Forms.TextBox txt_Telefono;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_DNI;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre_Completo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correo;
    }
}