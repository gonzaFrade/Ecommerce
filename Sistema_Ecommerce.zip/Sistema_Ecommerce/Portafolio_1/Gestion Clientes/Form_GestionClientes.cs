﻿using BE;
using BLL;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Portafolio_1
{
    public partial class Form_GestionClientes : Form
    {
        private BLL_Cliente _bl_Cliente = new BLL_Cliente();
        public Form_GestionClientes()
        {
            InitializeComponent();
        }

        private void Form_GestionClientes_Load(object sender, EventArgs e)
        {
            Mostrar();
            Filtrar();
        }

        private void Mostrar()
        {
            dataGridView1.Rows.Clear();

            foreach (Cliente pCliente in _bl_Cliente.ObtenerClientes())
                dataGridView1.Rows.Add(pCliente.DNI.ToString(), pCliente.Nombre.ToString(), pCliente.Telefono.ToString(), pCliente.Correo.ToString());
            groupBox1.BackColor = Color.White;
        }

        private void MostrarFiltrado(List<Cliente> pListaCliente)
        {
            dataGridView1.Rows.Clear();

            foreach (Cliente pCliente in pListaCliente)
                dataGridView1.Rows.Add(pCliente.DNI.ToString(), pCliente.Nombre.ToString(), pCliente.Telefono.ToString(), pCliente.Correo.ToString());

            groupBox1.BackColor = Color.White;
        }

        private void InformacionCliente()
        {
            txt_DNI.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            txt_Nombre.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            txt_Telefono.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            txt_Correo.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void BorrarInformacionCliente()
        {
            txt_DNI.Text = "";
            txt_Nombre.Text = "";
            txt_Telefono.Text = "";
            txt_Correo.Text = "";
        }

        private void Filtrar()
        {
            foreach (DataGridViewColumn dgv in dataGridView1.Columns)
                comboBox1.Items.Add(dgv.HeaderText);
        }

        private void btn_Registrar_Click_1(object sender, EventArgs e)
        {
            try
            {
                string _dni = txt_DNI.Text;

                if (string.IsNullOrEmpty(_dni))
                    throw new Exception("Ingrese un DNI!");

                if (!Information.IsNumeric(_dni))
                    throw new Exception("Ingrese un DNI valido! Que sea numerico!");

                if (_bl_Cliente.ObtenerClientes().Exists(x => x.DNI == int.Parse(_dni.ToString())))
                    throw new Exception("El DNI ingresado ya existe!");
                string _NombreCompleto = txt_Nombre.Text;

                if (string.IsNullOrEmpty(_NombreCompleto))
                    throw new Exception("Ingrese un nombre!");

                if (Information.IsNumeric(_NombreCompleto))
                    throw new Exception("Ingrese un nombre valido! No aceptamos números.");

                if (Regex.IsMatch(_NombreCompleto, @"\d"))
                    throw new Exception("Ingrese un nombre válido. No se permiten números.");

                string _Telefono = txt_Telefono.Text;

                if (string.IsNullOrEmpty(_Telefono))
                    throw new Exception("Ingrese un telefono!");

                if (!Information.IsNumeric(_Telefono))
                    throw new Exception("Ingrese un telefono valido! Que sea numerico!");

                string _correo = txt_Correo.Text;

                if (string.IsNullOrEmpty(_correo))
                    throw new Exception("Ingrese un correo!");

                Regex _validacion = new Regex(@"^\w+[\w.]*@[\w.]+\.[a-zA-Z]{3}(\.[a-zA-Z]{2,3})?$");

                if (!_validacion.IsMatch(txt_Correo.Text))
                    throw new Exception("El correo es invalido, ingrese uno correcto!");

                DialogResult r = MessageBox.Show("¿Desea crear al cliente?", "Crear Cliente", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    _bl_Cliente.AgregarCliente(new Cliente(int.Parse(_dni), _NombreCompleto, int.Parse(_Telefono), _correo));
                    Mostrar();
                    BorrarInformacionCliente();
                }
                else
                    MessageBox.Show("Se cancelo el registro el cliente");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            InformacionCliente();
        }

        private void Btn_BorrarDetalles_Click_1(object sender, EventArgs e)
        {
            BorrarInformacionCliente();
            this.dataGridView1.CurrentRow.Selected = false;
        }

        private void Btn_EliminarCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0)
                    throw new Exception("Registra un cliente para eliminar!");
                string _dni = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                Cliente pCliente = _bl_Cliente.ObtenerCliente(int.Parse(_dni));
                DialogResult r = MessageBox.Show("¿Desea eliminar al cliente?", "Eliminar Cliente", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    _bl_Cliente.EliminarCliente(pCliente);
                    Mostrar();
                    BorrarInformacionCliente();
                }
                else
                    MessageBox.Show("Se cancelo el registro el cliente");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_EditarCliente_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count == 0)
                    throw new Exception("Selecciona un cliente para editarlo!");

                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                string _dni = txt_DNI.Text;

                if (_dni != selectedRow.Cells["DNI"].Value.ToString())
                    throw new Exception("No se puede modificar el DNI de un cliente.");

                string _nombre = txt_Nombre.Text;

                if (string.IsNullOrEmpty(_nombre))
                    throw new Exception("Ingrese un nombre!");

                if (Information.IsNumeric((_nombre)))
                    throw new Exception("Ingrese un nombre válido! No aceptamos números.");

                if (Regex.IsMatch(_nombre, @"\d"))
                    throw new Exception("Ingrese un nombre válido. No se permiten números.");

                string _telefono = txt_Telefono.Text;
                if (string.IsNullOrEmpty(_telefono))
                    throw new Exception("Ingrese un teléfono!");

                if (!Information.IsNumeric(_telefono))
                    throw new Exception("Ingrese un teléfono válido! Que sea numérico!");

                string _correo = txt_Correo.Text;

                if (string.IsNullOrEmpty(_correo))
                    throw new Exception("Ingrese un correo!");

                Regex _validacion = new Regex(@"^\w+[\w.]*@[\w.]+\.[a-zA-Z]{3}(\.[a-zA-Z]{2,3})?$");

                if (!_validacion.IsMatch(txt_Correo.Text))
                    throw new Exception("El correo es inválido, ingrese uno correcto!");

                Cliente pCliente = new Cliente(int.Parse(_dni), _nombre, int.Parse(_telefono), _correo);
                DialogResult r = MessageBox.Show("¿Desea editar al cliente?", "Editar Cliente", MessageBoxButtons.YesNo);

                if (r == DialogResult.Yes)
                {
                    if (_bl_Cliente.ObtenerClientes().Exists(x => x.DNI == int.Parse(_dni) && x.DNI != int.Parse(selectedRow.Cells["DNI"].Value.ToString())))
                        throw new Exception("El DNI ingresado ya existe!");

                    _bl_Cliente.ModificarCliente(pCliente);
                    Mostrar();
                }
                else
                    MessageBox.Show("Se canceló la edición del cliente");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_BuscarFiltro_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text.Contains("DNI"))
                    MostrarFiltrado(_bl_Cliente.FiltrarDNI(textBox5.Text));
                else if (comboBox1.Text.Contains("Nombre"))
                    MostrarFiltrado(_bl_Cliente.FiltrarNombre(textBox5.Text));
                else if (comboBox1.Text.Contains("Telefono"))
                    MostrarFiltrado(_bl_Cliente.FiltrarTelefono(textBox5.Text));
                else if (comboBox1.Text.Contains("Correo"))
                    MostrarFiltrado(_bl_Cliente.FiltrarCorreo(textBox5.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_LimpiarTxt_Click(object sender, EventArgs e)
        {
            try
            {
                textBox5.Text = "";
                Mostrar();
                comboBox1.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
