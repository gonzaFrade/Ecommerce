﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Cliente
    {
        public Cliente(int pDNI, string pNombre, int pTelefono, string pCorreo)
        {
            DNI = pDNI;
            Nombre = pNombre;
            Telefono = pTelefono;
            Correo = pCorreo;
        }

        public int DNI { get; set; }
        public string Nombre { get; set; }
        public int Telefono { get; set; }
        public string Correo { get; set; }
    
    }
}
