﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Item
    {
        public Item(Producto pProducto, Venta pVenta, int pCantidad)
        {
            _producto = pProducto; _venta = pVenta; Cantidad = pCantidad;
        }

        public decimal PrecioUnitario { get { return _producto.Precio; } }
        public int Cantidad { get; set; }
        public decimal PrecioTotal { get{ return _producto.Precio * Cantidad; } }

        private Producto _producto { get; set; }
        private Venta _venta { get; set; }

        public Producto Producto()
        {
            return _producto;
        }

        public Venta Venta()
        {
            return _venta;
        }
    }
}
