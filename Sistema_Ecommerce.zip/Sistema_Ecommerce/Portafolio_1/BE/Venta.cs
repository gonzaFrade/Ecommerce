﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Venta
    {
        public Venta() { pListaItems = new List<Item>(); }
        public Venta(int pID,Cliente pCliente, DateTime pFecha)
        {
            ID = pID; Cliente = pCliente; Fecha = pFecha;
            pListaItems = new List<Item>();
        }

        public Venta(int pID, int pCliente, DateTime pFecha,decimal pPrecioTotal)
        {
            ID = pID; IDCliente = pCliente; Fecha = pFecha; PrecioTotal = pPrecioTotal;
            pListaItems = new List<Item>();
        }

        public int ID { get; set; }
        public Cliente Cliente { get; set; }
        public DateTime Fecha { get; set; }
        public decimal PrecioTotal { get; set; }
        public int IDCliente { get; set; }

        public List<Item> pListaItems;

        public void AgregarItem(Item pItem)
        {
            pListaItems.Add(pItem);
        }

        public List<Item> DevolverListaItems()
        {
            return pListaItems;
        }

        public void EditarItem(Item pItem)
        {
            foreach (var x in DevolverListaItems())
            {
                if (x.Producto().ID == pItem.Producto().ID)
                {
                    x.Cantidad = pItem.Cantidad; 
                    break;
                }
            }
        }

    }
}
