﻿using BE;
using DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapper
{
    public class Mapper_Producto
    {
        DAL_Producto _dao = new DAL_Producto();
        DataSet ds;
        public Mapper_Producto()
        {
            ds = _dao.RetornarDataSet();
            ds.Tables["Producto"].PrimaryKey = new DataColumn[] { ds.Tables["Producto"].Columns["ID"] };
        }

        public void AgregarProducto(Producto pProducto)
        {
            ds.Tables["Producto"].Rows.Add(pProducto.ID.ToString(), pProducto.Nombre.ToString(), pProducto.Precio.ToString(), pProducto.Categoria.ToString());
            _dao.GuardarDatos();
        }

        public void EliminarProducto(Producto pProducto)
        {
            DataRow dr = ds.Tables["Producto"].Rows.Find(pProducto.ID);
            dr.Delete();
            _dao.GuardarDatos();
        }

        public void ModificarProducto(Producto pProducto)
        {
            DataRow dr = ds.Tables["Producto"].Rows.Find(pProducto.ID);
            dr["Nombre"] = pProducto.Nombre;
            dr["Precio"] = pProducto.Precio;
            dr["Categoria"] = pProducto.Categoria;
            _dao.GuardarDatos();
        }

        public Producto ObtenerProducto(int ID)
        {
            DataRow dr = ds.Tables["Producto"].Rows.Find(ID);
            return new Producto(int.Parse(dr["ID"].ToString()), dr["Nombre"].ToString(), decimal.Parse(dr["Precio"].ToString()), dr["Categoria"].ToString());
        }

        public List<Producto> ObtenerListaProductos()
        {
            List<Producto> pListaProducto = new List<Producto>();
            foreach(DataRow dr in ds.Tables["Producto"].Rows)
            {
                pListaProducto.Add(new Producto(int.Parse(dr["ID"].ToString()), dr["Nombre"].ToString(), decimal.Parse(dr["Precio"].ToString()), dr["Categoria"].ToString()));
            }
            return pListaProducto;
        }

    }
}
