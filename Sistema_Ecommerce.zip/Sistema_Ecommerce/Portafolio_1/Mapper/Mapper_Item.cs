﻿using BE;
using DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Mapper
{
    public class Mapper_Item
    {
        DAL_Item _dao = new DAL_Item();
        DataSet ds;
        DAL_Producto _dao_Producto = new DAL_Producto();

        public Mapper_Item()
        {
            ds = _dao.RetornarDataSet();
            ds.Tables["Item"].PrimaryKey = new DataColumn[] { ds.Tables["Item"].Columns["ID_Producto"], ds.Tables["Item"].Columns["ID_Venta"] };
        }

        public void AgregarItem(Item pItem)
        {
            ds.Tables["Item"].Rows.Add(pItem.Producto().ID, pItem.Venta().ID, pItem.Cantidad);
            _dao.GuardarDatos();
        }

        public void EditarItem(Item pItem)
        {
            DataRow dr = ds.Tables["Item"].Rows.Find(new object[] { pItem.Producto().ID, pItem.Venta().ID });
            dr["Cantidad"] = pItem.Cantidad;
            _dao.GuardarDatos();
        }

        public List<Item> ObtenerListaItem(Venta pVenta)
        {
            List<Item> pListaItem = new List<Item>();
            foreach (DataRow dr in ds.Tables["Item"].Rows)
            {
                Producto pProducto = new Producto();
                foreach (DataRow drP in _dao_Producto.RetornarDataSet().Tables["Producto"].Rows)
                {
                    if (dr["ID_Producto"].ToString() == drP["ID"].ToString())
                    {
                        pProducto.ID = int.Parse(drP["ID"].ToString());
                        pProducto.Nombre = drP["Nombre"].ToString();
                        pProducto.Precio = decimal.Parse(drP["Precio"].ToString());
                        pProducto.Categoria = drP["Categoria"].ToString();
                        break;
                    }
                }
                if (dr["ID_Venta"].ToString() == pVenta.ID.ToString())
                {
                    pListaItem.Add(new Item(pProducto, pVenta, int.Parse(dr["Cantidad"].ToString())));
                }
            }
            return pListaItem;
        }

        public int ObtenerUltimoIDItem()
        {
            int _id = 0;
            foreach (DataRow dr in ds.Tables["Item"].Rows)
            {
                dr["ID"] = _id;
            }
            return _id;

        }
    }
}
