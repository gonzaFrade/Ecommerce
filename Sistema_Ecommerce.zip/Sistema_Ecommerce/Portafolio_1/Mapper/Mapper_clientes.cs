﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAO;
using BE;

namespace Mapper
{
    public class Mapper_clientes
    {
        DataSet ds;
        DAL_Cliente _dao;

        public Mapper_clientes()
        {
            _dao = new DAL_Cliente();
            ds = _dao.RetornarDataSet();
            ds.Tables["Cliente"].PrimaryKey = new DataColumn[] { ds.Tables["Cliente"].Columns["DNI"] };
        }

        public void AgregarCliente(Cliente pCliente)
        {
            ds.Tables["Cliente"].Rows.Add(int.Parse(pCliente.DNI.ToString()), pCliente.Nombre.ToString(), int.Parse(pCliente.Telefono.ToString()), pCliente.Correo.ToString());
            _dao.GuardarDatos();
        }

        public void EliminarCliente(Cliente pCliente)
        {
            DataRow dr = ds.Tables["Cliente"].Rows.Find(pCliente.DNI);
            dr.Delete();
            _dao.GuardarDatos();
        }

        public void ModificarCliente(Cliente pCliente)
        {
            DataRow dr = ds.Tables["Cliente"].Rows.Find(pCliente.DNI);
            dr["Nombre"] = pCliente.Nombre;
            dr["Telefono"] = int.Parse(pCliente.Telefono.ToString());
            dr["Correo"] = pCliente.Correo;
            _dao.GuardarDatos();
        }

        public Cliente ObtenerCliente(int _dni)
        {
            DataRow dr = ds.Tables["Cliente"].Rows.Find(_dni);
            return new Cliente(int.Parse(dr["DNI"].ToString()), dr["Nombre"].ToString(), int.Parse(dr["Telefono"].ToString()), dr["Correo"].ToString());
        }

        public List<Cliente> ObtenerClientes() 
        {
            List<Cliente> pListCliente = new List<Cliente>();
            foreach(DataRow dr in ds.Tables["Cliente"].Rows)
            {
                pListCliente.Add(new Cliente(int.Parse(dr["DNI"].ToString()), dr["Nombre"].ToString(), int.Parse(dr["Telefono"].ToString()), dr["Correo"].ToString()));
            }
            return pListCliente;
        }

        
    }
}
