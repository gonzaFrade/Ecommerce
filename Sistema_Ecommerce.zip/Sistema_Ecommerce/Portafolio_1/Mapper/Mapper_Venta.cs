﻿using BE;
using DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mapper
{
    public class Mapper_Venta
    {
        DataSet ds;
        DAL_Venta _dao = new DAL_Venta();
        Mapper_Item _mapper_Item = new Mapper_Item();
        DAL_Cliente _dao_Cliente = new DAL_Cliente();
        DAL_Item _dao_Item = new DAL_Item();
        Mapper_Producto _mapper_producto = new Mapper_Producto();

        public Mapper_Venta()
        {
            ds = _dao.RetornarDataSet();
            ds.Tables["Venta"].PrimaryKey = new DataColumn[] { ds.Tables["Venta"].Columns["ID"] };
        }

        public void AgregarVenta(Venta pVenta)
        {
            ds.Tables["Venta"].Rows.Add(pVenta.ID.ToString(),pVenta.Cliente.DNI.ToString(),pVenta.Fecha.ToString());
            _dao.GuardarDatos();
        }

        public void EliminarVenta(Venta pVenta)
        {
            DataRow dr = ds.Tables["Venta"].Rows.Find(pVenta.ID);
            dr.Delete();
            _dao.GuardarDatos();
        }

        public List<Venta> ObtenerListaVenta()
        {
            List<Venta> plista = new List<Venta>();
            foreach (DataRow dr in ds.Tables["Venta"].Rows)
            {
                Venta venta = new Venta();
                foreach(DataRow drC in _dao_Cliente.RetornarDataSet().Tables["Cliente"].Rows)
                {
                    if (dr["DNI_Cliente"].ToString() == drC["DNI"].ToString())
                    {
                        Cliente pCliente = new Cliente(int.Parse(drC["DNI"].ToString()), drC["Nombre"].ToString(), int.Parse(drC["Telefono"].ToString()), drC["Correo"].ToString());
                        venta.ID = int.Parse(dr["ID"].ToString());
                        venta.Cliente = pCliente; 
                        venta.Fecha = DateTime.Parse(dr["Fecha"].ToString());
                        foreach (Item item in _mapper_Item.ObtenerListaItem(venta))
                        {
                            venta.AgregarItem(item);
                        }
                        plista.Add(venta);
                    }
                }
            }
            return plista;
        }

        public Venta ObtenerVenta(Cliente pCliente)
        {
            Venta venta = new Venta();
            foreach (DataRow dr in ds.Tables["Venta"].Rows)
            {
                if (dr["DNI_Cliente"].ToString() == pCliente.DNI.ToString())
                {
                    venta = new Venta(int.Parse(dr["ID"].ToString()),pCliente,DateTime.Parse(venta.Fecha.ToString()));
                }
            }
            return venta;
        }

        public List<Venta> ObtenerTodasListaVenta()
        {
            List<Venta> listaVentas = new List<Venta>();
            List<Producto> listaProductos = _mapper_producto.ObtenerListaProductos();

            //Primero recorro la tabla de venta
            foreach (DataRow drVenta in ds.Tables["Venta"].Rows)
            {
                Venta venta = new Venta
                {
                    //Como no me interesa el cliente, no lo guardo.
                    ID = int.Parse(drVenta["ID"].ToString()),
                    Fecha = DateTime.Parse(drVenta["Fecha"].ToString())
                };
                //Luego recorro la tabla Item.
                foreach (DataRow drItem in _dao_Item.RetornarDataSet().Tables["Item"].Rows)
                {
                    if (drItem["ID_Venta"].ToString() == drVenta["ID"].ToString())
                    {
                        Producto producto = listaProductos.FirstOrDefault(p => p.ID == int.Parse(drItem["ID_Producto"].ToString()));
                        if (producto != null)
                        {
                            int cantidad = int.Parse(drItem["Cantidad"].ToString());
                            venta.AgregarItem(new Item(producto, venta, cantidad));
                        }
                    }
                }
                listaVentas.Add(venta);
            }

            return listaVentas;
        }


    }
}
